/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        forge: {
          bg: "rgb(var(--forge-bg) / <alpha-value>)",
          surface: "rgb(var(--forge-surface) / <alpha-value>)",
          card: "rgb(var(--forge-card) / <alpha-value>)",
          border: "rgb(var(--forge-border) / <alpha-value>)",
          accent: "rgb(var(--forge-accent) / <alpha-value>)",
          accentHover: "rgb(var(--forge-accent-hover) / <alpha-value>)",
          text: "rgb(var(--forge-text) / <alpha-value>)",
          muted: "rgb(var(--forge-muted) / <alpha-value>)",
          success: "rgb(var(--forge-success) / <alpha-value>)",
          warning: "rgb(var(--forge-warning) / <alpha-value>)",
          danger: "rgb(var(--forge-danger) / <alpha-value>)",
        },
      },
      fontFamily: {
        display: ["'DM Sans'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      animation: {
        "fade-in": "fadeIn 0.3s ease",
        "slide-up": "slideUp 0.3s ease",
        "pulse-soft": "pulseSoft 2s infinite",
        "float": "float 6s ease-in-out infinite",
        "float-delay": "float 6s ease-in-out 2s infinite",
        "gradient-shift": "gradientShift 8s ease infinite",
        "scale-in": "scaleIn 0.25s ease",
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: "translateY(12px)" }, to: { opacity: 1, transform: "translateY(0)" } },
        pulseSoft: { "0%,100%": { opacity: 1 }, "50%": { opacity: 0.6 } },
        float: {
          "0%,100%": { transform: "translateY(0) translateX(0)" },
          "50%": { transform: "translateY(-24px) translateX(12px)" },
        },
        gradientShift: {
          "0%,100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        scaleIn: { from: { opacity: 0, transform: "scale(0.96)" }, to: { opacity: 1, transform: "scale(1)" } },
      },
    },
  },
  plugins: [],
};
