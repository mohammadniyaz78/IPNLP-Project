let worker = null;
let idCounter = 0;
const pending = new Map();

const OP_TIMEOUT_MS = 20000;

function getWorker() {
  if (worker) return worker;

  worker = new Worker(new URL("../workers/imageWorker.js", import.meta.url), { type: "module" });

  worker.onmessage = (e) => {
    const { id, ok, error, width, height, buffer, histogram } = e.data;
    const entry = pending.get(id);
    if (!entry) return;
    pending.delete(id);
    clearTimeout(entry.timer);
    if (!ok) {
      entry.reject(new Error(error || "Image processing failed"));
    } else if (histogram) {
      entry.resolve(histogram);
    } else {
      entry.resolve(new ImageData(new Uint8ClampedArray(buffer), width, height));
    }
  };

  worker.onerror = (event) => {
    const err = new Error(event?.message || "The image-processing worker crashed");
    pending.forEach(entry => { clearTimeout(entry.timer); entry.reject(err); });
    pending.clear();
    // Force a fresh worker next time, in case this one is now unusable
    worker = null;
  };

  return worker;
}

// Spins up the worker (module parse + compile) ahead of time, so that cost is paid quietly
// in the background instead of during the user's first Apply click. Safe to call multiple
// times or before any image exists - it does no processing work by itself.
export function warmupWorker() {
  try {
    getWorker();
  } catch (err) {
    // If this fails, runImageOp will surface the real error on first actual use anyway.
  }
}

// Runs a processing op ('grayscale' | 'brightness' | 'blur' | 'sharpen' | 'edges') off the main
// thread. Always resolves or rejects - never hangs indefinitely, even if the worker itself stalls.
export function runImageOp(op, imageData, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++idCounter;
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error("This operation took too long and was cancelled. Try a smaller image or a lighter setting."));
      }
    }, OP_TIMEOUT_MS);

    pending.set(id, { resolve, reject, timer });

    try {
      const w = getWorker();
      // Copy the pixel buffer before transferring it - transferring detaches the buffer from
      // whichever array we hand over, and the caller still needs its own original ImageData intact.
      const copy = new Uint8ClampedArray(imageData.data);
      w.postMessage(
        { id, op, width: imageData.width, height: imageData.height, buffer: copy.buffer, params },
        [copy.buffer]
      );
    } catch (err) {
      clearTimeout(timer);
      pending.delete(id);
      reject(err);
    }
  });
}
