// All functions operate on ImageData and return a NEW ImageData (never mutate input in place
// where the caller still needs the original) so undo history snapshots stay independent.

export function cloneImageData(imageData) {
  return new ImageData(
    new Uint8ClampedArray(imageData.data),
    imageData.width,
    imageData.height
  );
}

export function toGrayscale(imageData) {
  const out = cloneImageData(imageData);
  const d = out.data;
  for (let i = 0; i < d.length; i += 4) {
    // luminance-weighted grayscale
    const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    d[i] = d[i + 1] = d[i + 2] = gray;
  }
  return out;
}

export function adjustBrightnessContrast(imageData, brightness = 0, contrast = 0) {
  // brightness: -100..100, contrast: -100..100
  const out = cloneImageData(imageData);
  const d = out.data;
  const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
  const b = (brightness / 100) * 255;
  for (let i = 0; i < d.length; i += 4) {
    d[i] = clamp(factor * (d[i] - 128) + 128 + b);
    d[i + 1] = clamp(factor * (d[i + 1] - 128) + 128 + b);
    d[i + 2] = clamp(factor * (d[i + 2] - 128) + 128 + b);
  }
  return out;
}

function clamp(v) {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

// Fast box blur (separable, multi-pass approximates gaussian) - radius in px
export function boxBlur(imageData, radius = 4) {
  radius = Math.max(1, Math.round(radius));
  let out = cloneImageData(imageData);
  // three passes of box blur approximates gaussian blur well
  for (let pass = 0; pass < 3; pass++) {
    out = boxBlurPass(out, radius);
  }
  return out;
}

function boxBlurPass(imageData, radius) {
  const { width, height, data } = imageData;
  const out = new Uint8ClampedArray(data.length);
  const tmp = new Uint8ClampedArray(data.length);

  // horizontal pass
  for (let y = 0; y < height; y++) {
    let rSum = 0, gSum = 0, bSum = 0, aSum = 0, count = 0;
    const rowStart = y * width * 4;
    for (let x = -radius; x <= radius; x++) {
      const xi = clampInt(x, 0, width - 1);
      const idx = rowStart + xi * 4;
      rSum += data[idx]; gSum += data[idx + 1]; bSum += data[idx + 2]; aSum += data[idx + 3];
      count++;
    }
    for (let x = 0; x < width; x++) {
      const idx = rowStart + x * 4;
      tmp[idx] = rSum / count; tmp[idx + 1] = gSum / count; tmp[idx + 2] = bSum / count; tmp[idx + 3] = aSum / count;
      const addXi = clampInt(x + radius + 1, 0, width - 1);
      const remXi = clampInt(x - radius, 0, width - 1);
      const addIdx = rowStart + addXi * 4;
      const remIdx = rowStart + remXi * 4;
      rSum += data[addIdx] - data[remIdx];
      gSum += data[addIdx + 1] - data[remIdx + 1];
      bSum += data[addIdx + 2] - data[remIdx + 2];
      aSum += data[addIdx + 3] - data[remIdx + 3];
    }
  }

  // vertical pass
  for (let x = 0; x < width; x++) {
    let rSum = 0, gSum = 0, bSum = 0, aSum = 0, count = 0;
    for (let y = -radius; y <= radius; y++) {
      const yi = clampInt(y, 0, height - 1);
      const idx = (yi * width + x) * 4;
      rSum += tmp[idx]; gSum += tmp[idx + 1]; bSum += tmp[idx + 2]; aSum += tmp[idx + 3];
      count++;
    }
    for (let y = 0; y < height; y++) {
      const idx = (y * width + x) * 4;
      out[idx] = rSum / count; out[idx + 1] = gSum / count; out[idx + 2] = bSum / count; out[idx + 3] = aSum / count;
      const addYi = clampInt(y + radius + 1, 0, height - 1);
      const remYi = clampInt(y - radius, 0, height - 1);
      const addIdx = (addYi * width + x) * 4;
      const remIdx = (remYi * width + x) * 4;
      rSum += tmp[addIdx] - tmp[remIdx];
      gSum += tmp[addIdx + 1] - tmp[remIdx + 1];
      bSum += tmp[addIdx + 2] - tmp[remIdx + 2];
      aSum += tmp[addIdx + 3] - tmp[remIdx + 3];
    }
  }

  return new ImageData(out, width, height);
}

function clampInt(v, min, max) {
  return v < min ? min : v > max ? max : v;
}

// Convolution-based sharpen. amount: 0..5
export function sharpen(imageData, amount = 1) {
  const a = Math.max(0, amount);
  const kernel = [
    0, -1 * a, 0,
    -1 * a, 1 + 4 * a, -1 * a,
    0, -1 * a, 0,
  ];
  return convolve(imageData, kernel, 3);
}

// Sobel edge detection, returns grayscale edge map
export function sobelEdges(imageData, threshold = 0) {
  const gray = toGrayscale(imageData);
  const { width, height, data } = gray;
  const out = new Uint8ClampedArray(data.length);

  const gxKernel = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
  const gyKernel = [-1, -2, -1, 0, 0, 0, 1, 2, 1];

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let gx = 0, gy = 0, k = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const xi = clampInt(x + kx, 0, width - 1);
          const yi = clampInt(y + ky, 0, height - 1);
          const val = data[(yi * width + xi) * 4];
          gx += val * gxKernel[k];
          gy += val * gyKernel[k];
          k++;
        }
      }
      let mag = Math.sqrt(gx * gx + gy * gy);
      if (mag < threshold) mag = 0;
      const idx = (y * width + x) * 4;
      const v = clamp(mag);
      out[idx] = out[idx + 1] = out[idx + 2] = v;
      out[idx + 3] = 255;
    }
  }
  return new ImageData(out, width, height);
}

function convolve(imageData, kernel, kSize) {
  const { width, height, data } = imageData;
  const out = new Uint8ClampedArray(data.length);
  const half = Math.floor(kSize / 2);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, k = 0;
      for (let ky = -half; ky <= half; ky++) {
        for (let kx = -half; kx <= half; kx++) {
          const xi = clampInt(x + kx, 0, width - 1);
          const yi = clampInt(y + ky, 0, height - 1);
          const idx = (yi * width + xi) * 4;
          const w = kernel[k];
          r += data[idx] * w;
          g += data[idx + 1] * w;
          b += data[idx + 2] * w;
          k++;
        }
      }
      const idx = (y * width + x) * 4;
      out[idx] = clamp(r);
      out[idx + 1] = clamp(g);
      out[idx + 2] = clamp(b);
      out[idx + 3] = data[idx + 3];
    }
  }
  return new ImageData(out, width, height);
}

export function computeHistogram(imageData) {
  const r = new Array(256).fill(0);
  const g = new Array(256).fill(0);
  const b = new Array(256).fill(0);
  const lum = new Array(256).fill(0);
  const d = imageData.data;
  for (let i = 0; i < d.length; i += 4) {
    r[d[i]]++;
    g[d[i + 1]]++;
    b[d[i + 2]]++;
    lum[Math.round(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2])]++;
  }
  return { r, g, b, lum };
}
