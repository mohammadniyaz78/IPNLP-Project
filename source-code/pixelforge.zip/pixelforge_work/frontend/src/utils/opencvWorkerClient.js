// Main-thread client for opencvWorker.js.
// OpenCV loads inside the worker via importScripts() (see opencvWorker.js for why that's safe
// here - it only blocks the worker's own thread, never the page). The "loading" phase message
// is posted immediately when a task arrives, arming the generous LOAD_TIMEOUT_MS below.
//
// Note: the actual historical cause of "OpenCV took too long to load" was NOT a slow load at
// all - it was a bug where the worker resolved a Promise with OpenCV's Module object itself,
// which is a "thenable" (has its own `.then`) and caused an infinite thenable-adoption loop
// that permanently froze the worker before it could ever reach the real processing step. See
// the detailed comment at the top of opencvWorker.js for the full explanation and fix. These
// timeouts remain as a legitimate safety net for genuinely slow/broken environments, but they
// were never the actual fix for the reported bug.
let worker = null;
let idCounter = 0;
const pending = new Map();

// LOAD_TIMEOUT_MS: budget for OpenCV's WASM init after the script is fetched.
// On a warm cache this is <1s; on a cold cache + slow CPU it can be several seconds.
// 90s is generous enough to never falsely fire on real hardware.
const LOAD_TIMEOUT_MS = 90_000;

// PROCESS_TIMEOUT_MS: budget for actual image processing (morphology / shape detection).
// Large images are downscaled before detection (see DETECT_MAX_DIMENSION in the worker),
// so processing should always be fast. 30s covers extreme edge cases.
const PROCESS_TIMEOUT_MS = 30_000;

// INITIAL_TIMEOUT_MS: tiny guard before the worker posts its first phase message.
// With fetch()-based loading the "loading" phase message arrives in <100ms even on a cold
// cache, because the message loop is alive. This is just a safety net for catastrophic
// failure (worker crash before first message). Keep it short so errors surface quickly.
const INITIAL_TIMEOUT_MS = 15_000;

function getWorker() {
  if (worker) return worker;

  // Classic (non-module) worker - see opencvWorker.js for why.
  worker = new Worker(new URL("../workers/opencvWorker.js", import.meta.url));

  worker.onmessage = (e) => {
    const { id, phase, ok, error, width, height, buffer, shapes } = e.data;
    const entry = pending.get(id);
    if (!entry) return;

    if (phase) {
      // Phase update: re-arm timeout with the appropriate budget for this phase.
      clearTimeout(entry.timer);
      const timeoutMs = phase === "loading" ? LOAD_TIMEOUT_MS : PROCESS_TIMEOUT_MS;
      const message = phase === "loading"
        ? "OpenCV took too long to load. Try reloading the page."
        : "OpenCV took too long to process this image. Try a smaller image.";
      entry.timer = setTimeout(() => {
        if (pending.has(id)) {
          pending.delete(id);
          entry.reject(new Error(message));
        }
      }, timeoutMs);
      entry.onPhase?.(phase);
      return;
    }

    pending.delete(id);
    clearTimeout(entry.timer);
    if (!ok) {
      entry.reject(new Error(error || "OpenCV processing failed"));
    } else {
      entry.resolve({ imageData: new ImageData(new Uint8ClampedArray(buffer), width, height), shapes });
    }
  };

  worker.onerror = (event) => {
    const err = new Error(event?.message || "The OpenCV worker crashed");
    pending.forEach(entry => { clearTimeout(entry.timer); entry.reject(err); });
    pending.clear();
    worker = null; // force a fresh worker next time
  };

  return worker;
}

// Spins up the worker and starts its OpenCV fetch+init ahead of time.
// Called on app mount (App.jsx) so the load is underway before the user interacts with
// Morph or Detect. Because loading now happens asynchronously inside the worker (fetch
// instead of importScripts), this never blocks the main thread.
export function warmupOpenCvWorker() {
  try {
    getWorker();
  } catch (err) {
    // Real error surfaces on first actual use.
  }
}

function runOpenCvTask(type, imageData, params, onPhase) {
  return new Promise((resolve, reject) => {
    const id = ++idCounter;

    // Initial short timer: guards the gap before the first phase message arrives.
    // With fetch()-based loading, "loading" phase arrives in <100ms, so this rarely matters.
    // It's a safety net for worker startup failure only.
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error("OpenCV worker did not respond. Try reloading the page."));
      }
    }, INITIAL_TIMEOUT_MS);

    pending.set(id, { resolve, reject, timer, onPhase });

    try {
      const w = getWorker();
      // Copy before transferring - transferring detaches the buffer, and the caller's
      // history entry still needs its own copy intact.
      const copy = new Uint8ClampedArray(imageData.data);
      w.postMessage(
        { id, type, imageData: { data: copy.buffer, width: imageData.width, height: imageData.height }, params },
        [copy.buffer]
      );
    } catch (err) {
      clearTimeout(timer);
      pending.delete(id);
      reject(err);
    }
  });
}

export function runMorphology(imageData, params, onPhase) {
  return runOpenCvTask("morphology", imageData, params, onPhase);
}

export function runDetectShapes(imageData, params, onPhase) {
  return runOpenCvTask("detect", imageData, params, onPhase);
}
