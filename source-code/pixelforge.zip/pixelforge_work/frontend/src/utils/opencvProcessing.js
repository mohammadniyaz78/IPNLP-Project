// Public API for the Morph and Detect tools. All the actual OpenCV computation now happens
// in opencvWorker.js (a Web Worker) - this module is a thin main-thread wrapper around
// opencvWorkerClient.js that only does the two things that genuinely need document/canvas
// access (drawing text labels) and can't run inside a worker.
//
// Why this file no longer runs OpenCV itself: OpenCV.js's WASM init and its actual
// morphology/contour computation are both real, synchronous CPU work. Running that on the
// main thread - which is what this file used to do - blocks React, paint, and input handling
// for however long that work takes, which is exactly what showed up as Chrome's "Page
// Unresponsive" warning when Morph or Detect was used. Moving that work into a Web Worker
// (opencvWorker.js) means it can take as long as it needs without ever freezing the tab.
import { runMorphology, runDetectShapes, warmupOpenCvWorker } from "./opencvWorkerClient";

function oddKernel(size) {
  return Math.max(1, Math.round(size) | 1);
}

const MORPH_LABELS = {
  dilate: "Dilated",
  erode: "Eroded",
  open: "Opened (noise removal)",
  close: "Closed (noise removal)",
};

export function morphologyLabel(operation, kernelSize, iterations) {
  return `${MORPH_LABELS[operation] || operation} (kernel ${oddKernel(kernelSize)}×${oddKernel(kernelSize)}, ×${iterations})`;
}

// Starts loading OpenCV.js in the background worker ahead of time. Called on app mount (see
// App.jsx) - this is safe to do unconditionally because it all happens inside a Worker thread
// and can never block the main thread, unlike the WASM init/compute work itself.
export function warmupOpenCv() {
  warmupOpenCvWorker();
}

// operation: "dilate" | "erode" | "open" | "close"
export async function applyMorphology(imageData, { operation, kernelSize = 3, iterations = 1 }, onPhase) {
  const ksize = oddKernel(kernelSize);
  const { imageData: result } = await runMorphology(imageData, { operation, kernelSize: ksize, iterations }, onPhase);
  return result;
}

function drawShapeLabels(imageData, labels) {
  // Text is rendered via canvas 2D on the main thread (cheap - a handful of fillRect/fillText
  // calls, not WASM computation) as a final pass on top of the worker's contour-outlined image.
  // This can't move into the worker: OffscreenCanvas text rendering support is inconsistent
  // across browsers, and this step is fast enough that it was never part of the freeze anyway.
  const canvas = document.createElement("canvas");
  canvas.width = imageData.width;
  canvas.height = imageData.height;
  const ctx = canvas.getContext("2d");
  ctx.putImageData(imageData, 0, 0);
  ctx.font = "600 13px 'DM Sans', sans-serif";
  ctx.textBaseline = "top";
  labels.forEach(({ type, x, y }) => {
    const paddingX = 5;
    const paddingY = 3;
    const textWidth = ctx.measureText(type).width;
    const labelY = Math.max(0, y - 20);
    ctx.fillStyle = "rgba(15, 17, 23, 0.78)";
    ctx.fillRect(x, labelY, textWidth + paddingX * 2, 18);
    ctx.fillStyle = "#4F7EFF";
    ctx.fillText(type, x + paddingX, labelY + paddingY);
  });
  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}

// Detects triangles, squares, rectangles, circles and other polygons in `imageData` (via the
// OpenCV worker) and returns a new ImageData with each shape outlined + labeled, plus the raw
// list of shapes found (for the UI summary in RightPanel).
export async function detectShapes(imageData, { minAreaPct = 0.5 } = {}, onPhase) {
  const { imageData: outlined, shapes } = await runDetectShapes(imageData, { minAreaPct }, onPhase);
  const withLabels = shapes.length ? drawShapeLabels(outlined, shapes) : outlined;
  return { imageData: withLabels, shapes };
}
