// Every editing operation's cost scales directly with total pixel count - no amount of
// threading or memoization changes that. Capping the working resolution puts a hard, visible
// ceiling on how much data ever gets processed, painted, or transferred to the worker, which
// is the one lever that actually reduces the *amount* of work rather than just its overhead.
// 1600px on the long edge is still sharp on virtually any screen; a 4000x3000 (12MP) phone
// photo becomes 1600x1200 - about 6x fewer pixels to process on every single edit.
//
// This lives in its own module (rather than inline in App.jsx) so the camera capture path
// (CameraCapture.jsx) can cap a frame to the *exact* same limit at the moment it's captured,
// instead of grabbing a full-resolution frame and only shrinking it a step later - that's the
// difference between processing one frame once, and processing it at full size and then again
// at edit size.
export const MAX_EDIT_DIMENSION = 1600;

export function fitWithinMaxDimension(width, height, maxDim = MAX_EDIT_DIMENSION) {
  const longEdge = Math.max(width, height);
  if (longEdge <= maxDim) return { width, height, scaled: false };
  const scale = maxDim / longEdge;
  return { width: Math.round(width * scale), height: Math.round(height * scale), scaled: true };
}
