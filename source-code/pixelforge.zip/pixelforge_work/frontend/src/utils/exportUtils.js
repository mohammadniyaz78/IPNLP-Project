// Encodes ImageData as an uncompressed 24-bit BMP (BITMAPINFOHEADER), which every
// browser/OS can open. Canvas.toBlob does not support 'image/bmp' reliably, so we
// build the file ourselves from the pixel buffer to guarantee real, non-empty output.
export function imageDataToBmpBlob(imageData) {
  const { width, height, data } = imageData;
  const rowSize = Math.floor((24 * width + 31) / 32) * 4; // rows padded to 4-byte boundary
  const pixelArraySize = rowSize * height;
  const fileSize = 54 + pixelArraySize;

  const buffer = new ArrayBuffer(fileSize);
  const view = new DataView(buffer);

  // BITMAPFILEHEADER (14 bytes)
  view.setUint8(0, 0x42); // 'B'
  view.setUint8(1, 0x4d); // 'M'
  view.setUint32(2, fileSize, true);
  view.setUint32(6, 0, true); // reserved
  view.setUint32(10, 54, true); // pixel data offset

  // BITMAPINFOHEADER (40 bytes)
  view.setUint32(14, 40, true); // header size
  view.setInt32(18, width, true);
  view.setInt32(22, height, true); // positive = bottom-up
  view.setUint16(26, 1, true); // planes
  view.setUint16(28, 24, true); // bits per pixel
  view.setUint32(30, 0, true); // no compression
  view.setUint32(34, pixelArraySize, true);
  view.setInt32(38, 2835, true); // ~72 DPI
  view.setInt32(42, 2835, true);
  view.setUint32(46, 0, true); // colors used
  view.setUint32(50, 0, true); // important colors

  // Pixel data: BMP stores rows bottom-up, BGR order, no alpha, padded to 4 bytes
  let offset = 54;
  for (let y = height - 1; y >= 0; y--) {
    let rowOffset = offset;
    for (let x = 0; x < width; x++) {
      const srcIdx = (y * width + x) * 4;
      const r = data[srcIdx];
      const g = data[srcIdx + 1];
      const b = data[srcIdx + 2];
      view.setUint8(rowOffset, b);
      view.setUint8(rowOffset + 1, g);
      view.setUint8(rowOffset + 2, r);
      rowOffset += 3;
    }
    offset += rowSize;
  }

  return new Blob([buffer], { type: "image/bmp" });
}

export function canvasToBlob(canvas, mime, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("toBlob returned null"))),
      mime,
      quality
    );
  });
}

// format: 'jpg' | 'png' | 'bmp'
export async function exportImageData(imageData, format, filenameBase = "pixelforge-export") {
  let blob;
  let ext;

  if (format === "bmp") {
    blob = imageDataToBmpBlob(imageData);
    ext = "bmp";
  } else {
    const canvas = document.createElement("canvas");
    canvas.width = imageData.width;
    canvas.height = imageData.height;
    const ctx = canvas.getContext("2d");
    if (format === "jpg") {
      // JPEG has no alpha channel - flatten onto white first to avoid black backgrounds
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.putImageData(imageData, 0, 0);
    const mime = format === "jpg" ? "image/jpeg" : "image/png";
    blob = await canvasToBlob(canvas, mime, format === "jpg" ? 0.95 : undefined);
    ext = format === "jpg" ? "jpg" : "png";
  }

  if (!blob || blob.size === 0) {
    throw new Error("Export produced an empty file");
  }

  downloadBlob(blob, `${filenameBase}.${ext}`);
  return blob;
}

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
