import { useState, useCallback, useRef, useEffect } from "react";
import Navbar from "./components/Navbar";
import LeftToolbar from "./components/LeftToolbar";
import ImageSourceScreen from "./components/ImageSourceScreen";
import ImageWorkspace from "./components/ImageWorkspace";
import RightPanel from "./components/RightPanel";
import PreviewModal from "./components/PreviewModal";
import Landing from "./pages/Landing";
import { runImageOp, warmupWorker } from "./utils/workerClient";
import { applyMorphology, morphologyLabel, detectShapes, warmupOpenCv } from "./utils/opencvProcessing";
import { MAX_EDIT_DIMENSION, fitWithinMaxDimension } from "./utils/imageSizing";

const DEFAULT_SHAPE_SETTINGS = {
  type: "rectangle",
  color: "#4F7EFF",
  fillColor: "#4F7EFF",
  fill: false,
  strokeWidth: 3,
};

export default function App() {
  const [page, setPage] = useState("landing"); // landing | source | editor
  const [image, setImage] = useState(null); // { file, url, name, size, type }
  const [history, setHistory] = useState([]); // [{ label, data: ImageData }]
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [activeTool, setActiveTool] = useState("upload");
  const [showPreview, setShowPreview] = useState(false);
  const [loadError, setLoadError] = useState(null);
  const [applyError, setApplyError] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  // Only set during Morph/Detect's "loading" phase (see opencvWorkerClient.js's onPhase) - lets
  // RightPanel show "Loading OpenCV…" instead of the generic "Processing…" so a slow first-time
  // WASM init doesn't read as a frozen/broken button. null the rest of the time, including
  // during ordinary (non-OpenCV) processing and during OpenCV's own "processing" phase.
  const [processingLabel, setProcessingLabel] = useState(null);

  // Pre-warm both workers as soon as the app mounts. This is cheap and safe for the plain JS
  // worker; it used to be treated as too risky to do unconditionally for the OpenCV worker,
  // on the theory that its WASM init does real synchronous work that could stall the UI. That
  // was true back when this ran on the main thread - it no longer applies now that init
  // happens inside opencvWorker.js's own Worker thread, which can never block React, paint, or
  // input handling no matter how long it takes. Starting it here (instead of waiting for the
  // user to select Morph/Detect - see handleToolSelect below, which still also calls this as a
  // no-op safety net) gives it the maximum possible head start: the entire time the user spends
  // picking/uploading an image and browsing tools, before they ever click Apply.
  useEffect(() => {
    warmupWorker();
    warmupOpenCv();
  }, []);

  // Note: brightness/contrast/blur/sharpen/edge slider values live LOCALLY in RightPanel,
  // not here. Keeping them out of App state means dragging a slider only re-renders
  // RightPanel itself, instead of cascading a re-render through the whole app (Navbar,
  // LeftToolbar, ImageWorkspace) on every tick of the drag.
  const [shapeSettings, setShapeSettings] = useState(DEFAULT_SHAPE_SETTINGS);

  // Most recent OpenCV shape-detection result, shown as a summary in the Detect panel.
  // Cleared whenever a new image is loaded/reset so it can't be shown against the wrong image.
  const [detectedShapes, setDetectedShapes] = useState([]);

  const loadTokenRef = useRef(0);

  const currentImageData = historyIndex >= 0 ? history[historyIndex]?.data : null;

  const pushHistory = useCallback((newData, label) => {
    setHistory(h => {
      const truncated = h.slice(0, historyIndex + 1);
      return [...truncated, { label, data: newData }];
    });
    setHistoryIndex(i => i + 1);
  }, [historyIndex]);

  const handleImageLoaded = useCallback((imageData) => {
    setLoadError(null);
    const token = ++loadTokenRef.current;

    const finish = (canvas, wasScaled, originalDims) => {
      if (loadTokenRef.current !== token) return;
      let data;
      try {
        data = canvas.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, canvas.width, canvas.height);
      } catch (err) {
        setLoadError("This image couldn't be read (it may be corrupted or in an unsupported format).");
        return;
      }
      setImage({ ...imageData, wasScaled, originalDims });
      setHistory([{ label: `Loaded "${imageData.name}"`, data }]);
      setHistoryIndex(0);
      setActiveTool("upload");
      setShapeSettings(DEFAULT_SHAPE_SETTINGS);
      setDetectedShapes([]);
      setPage("editor");
    };

    // Fallback for the rare format createImageBitmap can't decode but <img> still can.
    const loadViaImgElement = () => {
      const img = new Image();
      img.onload = () => {
        if (loadTokenRef.current !== token) return;
        const { width, height, scaled } = fitWithinMaxDimension(img.naturalWidth, img.naturalHeight, MAX_EDIT_DIMENSION);
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        canvas.getContext("2d", { willReadFrequently: true }).drawImage(img, 0, 0, width, height);
        finish(canvas, scaled, { width: img.naturalWidth, height: img.naturalHeight });
      };
      img.onerror = () => {
        if (loadTokenRef.current !== token) return;
        setLoadError("This image failed to load. Please try a different file.");
      };
      img.src = imageData.url;
    };

    (async () => {
      try {
        // createImageBitmap decodes off the main thread (browser-native, often hardware
        // accelerated) - this is the part of "loading" that used to visibly stall the UI
        // for large camera/phone photos with the old <img onload> + drawImage path.
        const bitmap = await createImageBitmap(imageData.file);
        if (loadTokenRef.current !== token) { bitmap.close?.(); return; } // superseded

        const { width, height, scaled } = fitWithinMaxDimension(bitmap.width, bitmap.height, MAX_EDIT_DIMENSION);
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        // willReadFrequently hints the browser to use a readback-optimized backing store,
        // since we call getImageData/putImageData on this data repeatedly during editing.
        // Drawing directly at the target (possibly downscaled) size lets the browser's own
        // (often hardware-accelerated) resampler do the downscale in one step.
        canvas.getContext("2d", { willReadFrequently: true }).drawImage(bitmap, 0, 0, width, height);
        const originalDims = { width: bitmap.width, height: bitmap.height };
        bitmap.close?.();
        finish(canvas, scaled, originalDims);
      } catch (err) {
        if (loadTokenRef.current !== token) return;
        loadViaImgElement();
      }
    })();
  }, []);

  const isProcessingRef = useRef(false); // synchronous lock - closes a timing gap that a
  // React-state-only check can't: two rapid clicks handled within the same tick would both
  // still see the OLD `isProcessing` value from their shared render closure, since React
  // hasn't committed the state update yet. A plain ref updates immediately, with no such gap.

  const applyEdit = useCallback(async (op, params, label) => {
    if (!currentImageData || isProcessingRef.current) return;
    isProcessingRef.current = true;
    setIsProcessing(true);
    const t0 = performance.now();
    try {
      const result = await runImageOp(op, currentImageData, params);
      const elapsed = (performance.now() - t0).toFixed(0);
      console.log(`PixelForge: "${op}" on ${currentImageData.width}×${currentImageData.height} took ${elapsed}ms`);
      pushHistory(result, label);
      setApplyError(null);
    } catch (err) {
      console.error("PixelForge: edit failed —", err);
      setApplyError(`Couldn't apply that edit: ${err.message || err}`);
    } finally {
      isProcessingRef.current = false;
      setIsProcessing(false);
    }
  }, [currentImageData, pushHistory]);

  const handleApplyGrayscale = useCallback(() => {
    applyEdit("grayscale", {}, "Applied Grayscale");
  }, [applyEdit]);

  const handleApplyBrightness = useCallback((brightness, contrast) => {
    applyEdit("brightness", { brightness, contrast }, "Adjusted Brightness/Contrast");
  }, [applyEdit]);

  const handleApplyBlur = useCallback((radius) => {
    applyEdit("blur", { radius }, `Applied Blur (r=${radius})`);
  }, [applyEdit]);

  const handleApplySharpen = useCallback((amount) => {
    applyEdit("sharpen", { amount }, `Applied Sharpen (${amount})`);
  }, [applyEdit]);

  const handleApplyEdges = useCallback((threshold) => {
    applyEdit("edges", { threshold }, "Applied Edge Detection");
  }, [applyEdit]);

  // Dilation/erosion/opening/closing run through OpenCV in its own dedicated Web Worker
  // (opencvWorker.js, via opencvProcessing.js) rather than the plain JS worker used for
  // grayscale/blur/etc - see opencvWorker.js for why. Mirrors applyEdit's isProcessing/
  // error/history handling so it behaves identically from the UI's point of view.
  const handleApplyMorphology = useCallback(async (operation, kernelSize, iterations) => {
    if (!currentImageData || isProcessingRef.current) return;
    isProcessingRef.current = true;
    setIsProcessing(true);
    const t0 = performance.now();
    try {
      const onPhase = (phase) => setProcessingLabel(phase === "loading" ? "Loading OpenCV…" : null);
      const result = await applyMorphology(currentImageData, { operation, kernelSize, iterations }, onPhase);
      const elapsed = (performance.now() - t0).toFixed(0);
      console.log(`PixelForge: opencv "${operation}" on ${currentImageData.width}×${currentImageData.height} took ${elapsed}ms`);
      pushHistory(result, morphologyLabel(operation, kernelSize, iterations));
      setApplyError(null);
    } catch (err) {
      console.error("PixelForge: opencv morphology failed —", err);
      setApplyError(`Couldn't apply that edit: ${err.message || err}`);
    } finally {
      isProcessingRef.current = false;
      setIsProcessing(false);
      setProcessingLabel(null);
    }
  }, [currentImageData, pushHistory]);

  const handleApplyDetectShapes = useCallback(async (minAreaPct) => {
    if (!currentImageData || isProcessingRef.current) return;
    isProcessingRef.current = true;
    setIsProcessing(true);
    const t0 = performance.now();
    try {
      const onPhase = (phase) => setProcessingLabel(phase === "loading" ? "Loading OpenCV…" : null);
      const { imageData: result, shapes } = await detectShapes(currentImageData, { minAreaPct }, onPhase);
      const elapsed = (performance.now() - t0).toFixed(0);
      console.log(`PixelForge: opencv shape detection on ${currentImageData.width}×${currentImageData.height} took ${elapsed}ms — found ${shapes.length} shape(s)`);
      setDetectedShapes(shapes);
      pushHistory(result, `Detected ${shapes.length} shape${shapes.length === 1 ? "" : "s"}`);
      setApplyError(null);
    } catch (err) {
      console.error("PixelForge: opencv shape detection failed —", err);
      setApplyError(`Couldn't detect shapes: ${err.message || err}`);
    } finally {
      isProcessingRef.current = false;
      setIsProcessing(false);
      setProcessingLabel(null);
    }
  }, [currentImageData, pushHistory]);

  const handleCommitShape = useCallback((newData, label) => {
    pushHistory(newData, label);
  }, [pushHistory]);

  const handleUndo = useCallback(() => {
    setHistoryIndex(i => Math.max(0, i - 1));
  }, []);

  const handleRedo = useCallback(() => {
    setHistoryIndex(i => Math.min(history.length - 1, i + 1));
  }, [history.length]);

  const handleReset = useCallback(() => {
    setHistoryIndex(0);
    setHistory(h => h.slice(0, 1));
    setDetectedShapes([]);
  }, []);

  const handleStartOver = useCallback(() => {
    setImage(null);
    setHistory([]);
    setHistoryIndex(-1);
    setActiveTool("upload");
    setDetectedShapes([]);
    setPage("source");
  }, []);

  const handleGoHome = useCallback(() => {
    setPage("landing");
  }, []);

  // Safety net only - the real warmup call is on app mount above. This just covers the edge
  // case where the OpenCV worker somehow never got created (e.g. it crashed earlier and
  // worker.onerror nulled it out) by the time the user picks one of its tools.
  const handleToolSelect = useCallback((toolId) => {
    setActiveTool(toolId);
    if (toolId === "morphology" || toolId === "detect") {
      warmupOpenCv();
    }
  }, []);

  const handleOpenPreview = useCallback(() => setShowPreview(true), []);
  const handleClosePreview = useCallback(() => setShowPreview(false), []);

  if (page === "landing") {
    return <Landing onStart={() => setPage("source")} />;
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-forge-bg">
      <Navbar image={image} onLogoClick={handleGoHome} onStartOver={image ? handleStartOver : null} startOverDisabled={isProcessing} />
      <div className="flex flex-1 overflow-hidden">
        {page === "editor" && image && (
          <LeftToolbar activeTool={activeTool} onToolSelect={handleToolSelect} disabled={isProcessing} />
        )}

        <main className="flex-1 overflow-hidden p-4">
          {page === "source" || !image ? (
            <>
              <ImageSourceScreen onImageLoaded={handleImageLoaded} />
              {loadError && (
                <p className="text-center text-forge-danger text-xs font-mono mt-3">{loadError}</p>
              )}
            </>
          ) : (
            <ImageWorkspace
              original={image}
              imageData={currentImageData}
              activeTool={activeTool}
              shapeSettings={shapeSettings}
              onCommitShape={handleCommitShape}
            />
          )}
        </main>

        {page === "editor" && image && (
          <RightPanel
            activeTool={activeTool}
            image={image}
            imageData={currentImageData}
            history={history}
            historyIndex={historyIndex}
            onUndo={handleUndo}
            onRedo={handleRedo}
            onReset={handleReset}
            shapeSettings={shapeSettings}
            setShapeSettings={setShapeSettings}
            onApplyGrayscale={handleApplyGrayscale}
            onApplyBrightness={handleApplyBrightness}
            onApplyBlur={handleApplyBlur}
            onApplySharpen={handleApplySharpen}
            onApplyEdges={handleApplyEdges}
            onApplyMorphology={handleApplyMorphology}
            onApplyDetectShapes={handleApplyDetectShapes}
            detectedShapes={detectedShapes}
            onOpenPreview={handleOpenPreview}
            applyError={applyError}
            isProcessing={isProcessing}
            processingLabel={processingLabel}
          />
        )}
      </div>

      {showPreview && currentImageData && (
        <PreviewModal
          imageData={currentImageData}
          filenameBase={(image?.name || "pixelforge-export").replace(/\.[^/.]+$/, "")}
          onClose={handleClosePreview}
        />
      )}
    </div>
  );
}
