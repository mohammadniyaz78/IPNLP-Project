import {
  toGrayscale,
  adjustBrightnessContrast,
  boxBlur,
  sharpen,
  sobelEdges,
  computeHistogram,
} from "../utils/imageProcessing";

self.onmessage = (e) => {
  const { id, op, width, height, buffer, params } = e.data;
  try {
    const data = new Uint8ClampedArray(buffer);
    const imageData = new ImageData(data, width, height);

    let result;
    switch (op) {
      case "grayscale":
        result = toGrayscale(imageData);
        break;
      case "brightness":
        result = adjustBrightnessContrast(imageData, params.brightness, params.contrast);
        break;
      case "blur":
        result = boxBlur(imageData, params.radius);
        break;
      case "sharpen":
        result = sharpen(imageData, params.amount);
        break;
      case "edges":
        result = sobelEdges(imageData, params.threshold);
        break;
      case "histogram": {
        const hist = computeHistogram(imageData);
        self.postMessage({ id, ok: true, histogram: hist });
        return;
      }
      default:
        throw new Error(`Unknown operation: ${op}`);
    }

    // Transfer the underlying buffer back instead of copying it - fast and avoids
    // doubling memory for large images.
    self.postMessage(
      { id, ok: true, width: result.width, height: result.height, buffer: result.data.buffer },
      [result.data.buffer]
    );
  } catch (err) {
    self.postMessage({ id, ok: false, error: err?.message || String(err) });
  }
};
