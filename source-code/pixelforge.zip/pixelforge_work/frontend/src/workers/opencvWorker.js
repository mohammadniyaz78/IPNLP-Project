// Classic (non-module) worker - deliberately NOT `{ type: "module" }` - because it needs
// to load OpenCV.js's UMD build, which module workers don't support directly.
//
// ============================================================================================
// ACTUAL ROOT CAUSE OF "OpenCV took too long to load" (found by instrumenting the load
// with postMessage-based tracing and watching exactly where the worker stalls):
//
// OpenCV.js's Module object (`cv`) implements its own `.then(func)` method so that code can
// do `createOpenCVModule().then(cv => ...)`. That makes `cv` a "thenable" - any object with a
// callable `.then` property.
//
// Both this worker's previous version AND the standard "recommended" OpenCV.js worker
// pattern resolved a Promise with the `cv` object itself once ready, e.g.:
//     await new Promise((resolve) => { cv.onRuntimeInitialized = resolve; });
//     return cv;                                    // <- returned from an async function
// or
//     cv.onRuntimeInitialized = () => resolve(cv);   // <- resolved directly with cv
//
// Per the JS spec, resolving a Promise (or returning a value from an async function) with a
// thenable does NOT just fulfill the promise with that value - the engine instead calls
// `value.then(resolve, reject)` and adopts whatever that call does. OpenCV's own
// `Module.then` implementation is:
//     Module["then"] = function (func) {
//       if (calledRun) { func(Module) } else { ...wrap onRuntimeInitialized... }
//       return Module;
//     };
// By the time `onRuntimeInitialized` fires, `calledRun` is already true, so adopting `cv` as
// a thenable calls `func(Module)` - but `Module` (== `cv`) is STILL thenable, so the engine's
// internal resolution machinery treats *that* call's argument as thenable too, and repeats.
// This creates an infinite chain of queued microtasks that adopt `cv` as a thenable, over and
// over, forever. It never throws and never resolves - it just permanently occupies the
// worker's microtask queue, which starves every other pending callback (including the
// "processing" phase message and the actual morphology/detect work) from ever running again.
// This reproduced 100% of the time in testing, on every machine and every network condition -
// exactly matching "I have already reported this many times, but the same error is still
// happening": the bug was never about slow loading, so a longer timeout could never fix it.
//
// THE FIX: never resolve a Promise, or `return` from an async function, with the `cv`/Module
// object itself. Resolve with a plain boolean instead, and read `self.cv` separately once the
// promise settles (see loadCv() below).
//
// A plain, synchronous importScripts() call is used to load opencv.js - this is the standard,
// documented way to load OpenCV.js in a Worker. It runs on the WORKER's own thread, so it
// cannot freeze the page's UI even though it blocks this worker's loop for the ~1s it takes to
// parse; the main thread and page stay fully responsive throughout.
//
// OpenCV is loaded from our own origin (copied into public/opencv/ by scripts/copy-opencv.js)
// so the browser can cache it aggressively and subsequent loads are near-instant.
// ============================================================================================
const OPENCV_SCRIPT_URL = new URL("/opencv/opencv.js", self.location.origin).href;

// Module-level singleton: once loaded, cv is reused for ALL operations in this worker's
// lifetime. The worker itself is also a singleton (see opencvWorkerClient.js), so OpenCV
// loads at most once per browser tab.
let cvReadyPromise = null;

function loadCv() {
  if (cvReadyPromise) return cvReadyPromise;

  cvReadyPromise = (async () => {
    try {
      // Synchronous inside this worker thread only - never touches the main/UI thread.
      importScripts(OPENCV_SCRIPT_URL);
    } catch (err) {
      cvReadyPromise = null; // allow retry
      throw new Error(`Couldn't load opencv.js: ${err.message}`);
    }

    const cv = self.cv;
    if (!cv) {
      cvReadyPromise = null;
      throw new Error("OpenCV script loaded but did not attach itself to the worker scope.");
    }

    // Wait for the WASM runtime to finish initializing if needed.
    // IMPORTANT: resolve with a plain boolean, NOT with `cv` - see the note at the top of this
    // file. `cv` has a `.then` method, so resolving/returning it directly makes the engine
    // treat it as a thenable and never actually settle the promise.
    if (!cv.Mat) {
      await new Promise((resolve) => {
        cv.onRuntimeInitialized = () => resolve(true);
      });
    }

    return true;
  })().catch((err) => {
    cvReadyPromise = null; // allow retry on failure
    throw err;
  });

  return cvReadyPromise;
}

// Start loading OpenCV immediately when the worker is created (before any task arrives).
// Combined with opencvWorkerClient.js's warmupOpenCvWorker() - called on app mount -
// this means loading is typically complete by the time the user clicks Apply.
// Rejection is intentionally swallowed here; errors surface through the per-task loadCv() call.
loadCv().catch(() => {});

function oddKernel(size) {
  return Math.max(1, Math.round(size) | 1);
}

// Copies a Mat's pixel data out into a plain Uint8ClampedArray + dimensions (converting to
// RGBA first if needed) BEFORE the caller deletes the Mat, since Mat memory lives in the
// WASM heap and is gone the instant .delete() runs.
function matToBuffer(cv, mat) {
  let rgba = mat;
  let temp = null;
  if (mat.channels() === 1) {
    temp = new cv.Mat();
    cv.cvtColor(mat, temp, cv.COLOR_GRAY2RGBA, 0);
    rgba = temp;
  } else if (mat.channels() === 3) {
    temp = new cv.Mat();
    cv.cvtColor(mat, temp, cv.COLOR_RGB2RGBA, 0);
    rgba = temp;
  }
  const data = new Uint8ClampedArray(rgba.data);
  const width = rgba.cols;
  const height = rgba.rows;
  if (temp) temp.delete();
  return { data, width, height };
}

function runMorphology(cv, { data, width, height }, { operation, kernelSize, iterations }) {
  const imageData = new ImageData(new Uint8ClampedArray(data), width, height);
  const src = cv.matFromImageData(imageData);
  const dst = new cv.Mat();
  const ksize = oddKernel(kernelSize);
  const kernel = cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(ksize, ksize));
  const anchor = new cv.Point(-1, -1);
  try {
    switch (operation) {
      case "dilate":
        cv.dilate(src, dst, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "erode":
        cv.erode(src, dst, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "open":
        cv.morphologyEx(src, dst, cv.MORPH_OPEN, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "close":
        cv.morphologyEx(src, dst, cv.MORPH_CLOSE, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      default:
        throw new Error(`Unknown morphology operation: ${operation}`);
    }
    return { result: matToBuffer(cv, dst), shapes: null };
  } finally {
    src.delete();
    dst.delete();
    kernel.delete();
  }
}

function hasRightAngles(approx) {
  const pts = [];
  for (let i = 0; i < 4; i++) {
    pts.push({ x: approx.data32S[i * 2], y: approx.data32S[i * 2 + 1] });
  }
  for (let i = 0; i < 4; i++) {
    const prev = pts[(i + 3) % 4];
    const curr = pts[i];
    const next = pts[(i + 1) % 4];
    const v1 = { x: prev.x - curr.x, y: prev.y - curr.y };
    const v2 = { x: next.x - curr.x, y: next.y - curr.y };
    const mag1 = Math.hypot(v1.x, v1.y) || 1;
    const mag2 = Math.hypot(v2.x, v2.y) || 1;
    const cosAngle = (v1.x * v2.x + v1.y * v2.y) / (mag1 * mag2);
    if (Math.abs(cosAngle) > 0.35) return false; // ~70°-110° tolerance
  }
  return true;
}

function classifyContour(approx, area, peri, rect) {
  const vertices = approx.rows;
  const circularity = peri > 0 ? (4 * Math.PI * area) / (peri * peri) : 0;
  if (vertices === 3) return "Triangle";
  if (vertices === 4) {
    if (!hasRightAngles(approx)) return "Quadrilateral";
    const aspect = rect.width / Math.max(1, rect.height);
    return aspect > 0.9 && aspect < 1.1 ? "Square" : "Rectangle";
  }
  if (vertices === 5) return "Pentagon";
  if (vertices === 6) return "Hexagon";
  return circularity > 0.78 ? "Circle" : `Polygon (${vertices} sides)`;
}

// Contour detection cost scales with pixel count. Detection runs on a capped-size copy and
// the resulting contours/rects are scaled back up to the original image's coordinate space.
const DETECT_MAX_DIMENSION = 900;

function runDetectShapes(cv, { data, width, height }, { minAreaPct }) {
  const imageData = new ImageData(new Uint8ClampedArray(data), width, height);
  const src = cv.matFromImageData(imageData);
  const scale = Math.min(1, DETECT_MAX_DIMENSION / Math.max(width, height));
  const small = new cv.Mat();
  const gray = new cv.Mat();
  const blurred = new cv.Mat();
  const thresh = new cv.Mat();
  const noiseKernel = cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(3, 3));
  const contours = new cv.MatVector();
  const hierarchy = new cv.Mat();
  const output = src.clone();

  try {
    if (scale < 1) {
      cv.resize(src, small, new cv.Size(0, 0), scale, scale, cv.INTER_AREA);
    } else {
      src.copyTo(small);
    }

    cv.cvtColor(small, gray, cv.COLOR_RGBA2GRAY, 0);
    cv.GaussianBlur(gray, blurred, new cv.Size(5, 5), 0, 0, cv.BORDER_DEFAULT);

    cv.threshold(blurred, thresh, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU);
    const totalPx = thresh.rows * thresh.cols;
    if (cv.countNonZero(thresh) > totalPx / 2) {
      cv.bitwise_not(thresh, thresh);
    }

    const anchor = new cv.Point(-1, -1);
    cv.morphologyEx(thresh, thresh, cv.MORPH_OPEN, noiseKernel, anchor, 1, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
    cv.morphologyEx(thresh, thresh, cv.MORPH_CLOSE, noiseKernel, anchor, 1, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());

    cv.findContours(thresh, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);

    const imgArea = small.rows * small.cols;
    const minArea = Math.max(40, imgArea * (minAreaPct / 100));
    const strokeColor = new cv.Scalar(79, 126, 255, 255); // forge-accent, RGBA
    const inv = scale < 1 ? 1 / scale : 1;

    const shapes = [];
    for (let i = 0; i < contours.size(); i++) {
      const cnt = contours.get(i);
      const area = cv.contourArea(cnt, false);
      if (area < minArea) {
        cnt.delete();
        continue;
      }
      const peri = cv.arcLength(cnt, true);
      const approx = new cv.Mat();
      cv.approxPolyDP(cnt, approx, 0.03 * peri, true);
      const rect = cv.boundingRect(cnt);
      const type = classifyContour(approx, area, peri, rect);

      if (scale < 1) {
        for (let p = 0; p < cnt.data32S.length; p++) cnt.data32S[p] = Math.round(cnt.data32S[p] * inv);
      }
      cv.drawContours(output, contours, i, strokeColor, 2, cv.LINE_AA, hierarchy, 0);
      shapes.push({
        type,
        x: Math.round(rect.x * inv),
        y: Math.round(rect.y * inv),
        width: Math.round(rect.width * inv),
        height: Math.round(rect.height * inv),
        area: Math.round(area * inv * inv),
      });

      approx.delete();
      cnt.delete();
    }

    return { result: matToBuffer(cv, output), shapes };
  } finally {
    src.delete();
    small.delete();
    gray.delete();
    blurred.delete();
    thresh.delete();
    noiseKernel.delete();
    contours.delete();
    hierarchy.delete();
    output.delete();
  }
}

self.onmessage = async (e) => {
  const { id, type, imageData, params } = e.data;
  try {
    // Post "loading" phase immediately so the client can arm its generous load-budget timeout.
    self.postMessage({ id, phase: "loading" });
    await loadCv();
    const cv = self.cv; // loadCv() resolves to `true`, not `cv` - see note above loadCv().
    // Post "processing" phase to reset timeout to the tighter processing budget.
    self.postMessage({ id, phase: "processing" });

    const { result, shapes } = type === "morphology"
      ? runMorphology(cv, imageData, params)
      : type === "detect"
      ? runDetectShapes(cv, imageData, params)
      : (() => { throw new Error(`Unknown opencv worker task: ${type}`); })();

    self.postMessage(
      { id, ok: true, width: result.width, height: result.height, buffer: result.data.buffer, shapes },
      [result.data.buffer]
    );
  } catch (err) {
    self.postMessage({ id, ok: false, error: (err && err.message) || String(err) });
  }
};
