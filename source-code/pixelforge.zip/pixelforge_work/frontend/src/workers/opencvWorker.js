// Classic (non-module) worker - deliberately NOT `{ type: "module" }` - because it needs
// to load OpenCV.js's UMD build, which module workers don't support directly.
//
// ROOT CAUSE OF "OpenCV took too long to load":
// The previous version used importScripts(), which is SYNCHRONOUS inside the worker thread.
// importScripts() blocks the worker's entire event loop while the 9.9MB opencv.js file
// loads and parses - during that time, no messages can be received or sent, so the
// main-thread timeout fires before the worker can even post its first "loading" phase
// acknowledgement. On slower machines, high-memory-pressure situations, or cold cache,
// this synchronous block could easily exceed the timeout.
//
// FIX: Use fetch() + indirect eval to load OpenCV asynchronously. This keeps the worker's
// message loop alive during the load, so phase messages are sent promptly and the timeout
// only needs to cover actual slow scenarios (not the normal fast-path).
//
// OpenCV is loaded from our own origin (copied into public/opencv/ by scripts/copy-opencv.js)
// so the browser can cache it aggressively and subsequent loads are near-instant.
const OPENCV_SCRIPT_URL = new URL("/opencv/opencv.js", self.location.origin).href;

// Module-level singleton: once loaded, cv is reused for ALL operations in this worker's
// lifetime. The worker itself is also a singleton (see opencvWorkerClient.js), so OpenCV
// loads at most once per browser tab.
let cvReadyPromise = null;

function loadCv() {
  if (cvReadyPromise) return cvReadyPromise;

  cvReadyPromise = (async () => {
    // Use fetch() instead of importScripts() so the load is non-blocking.
    // importScripts() freezes the worker's event loop for the entire duration of the
    // network fetch + parse, which is what caused the timeout. fetch() is async and
    // keeps the message loop alive.
    let scriptText;
    try {
      const resp = await fetch(OPENCV_SCRIPT_URL);
      if (!resp.ok) throw new Error(`HTTP ${resp.status} fetching opencv.js`);
      scriptText = await resp.text();
    } catch (err) {
      cvReadyPromise = null; // allow retry
      throw new Error(`Couldn't fetch opencv.js: ${err.message}`);
    }

    // Execute the UMD script in worker scope. This is the standard pattern for
    // loading non-module UMD scripts asynchronously in a worker.
    try {
      // eslint-disable-next-line no-new-func
      new Function(scriptText)();
    } catch (err) {
      cvReadyPromise = null;
      throw new Error(`opencv.js failed to execute: ${err.message}`);
    }

    const cv = self.cv;
    if (!cv) {
      cvReadyPromise = null;
      throw new Error("OpenCV script loaded but did not attach itself to the worker scope.");
    }

    // Wait for WASM runtime to finish initializing if needed.
    if (!cv.Mat) {
      await new Promise((resolve) => { cv.onRuntimeInitialized = resolve; });
    }

    return cv;
  })().catch((err) => {
    cvReadyPromise = null; // allow retry on failure
    throw err;
  });

  return cvReadyPromise;
}

// Start loading OpenCV immediately when the worker is created (before any task arrives).
// Combined with opencvWorkerClient.js's warmupOpenCvWorker() - called on app mount -
// this means loading is typically complete by the time the user clicks Apply.
// Rejection is intentionally swallowed here; errors surface through the per-task loadCv() call.
loadCv().catch(() => {});

function oddKernel(size) {
  return Math.max(1, Math.round(size) | 1);
}

// Copies a Mat's pixel data out into a plain Uint8ClampedArray + dimensions (converting to
// RGBA first if needed) BEFORE the caller deletes the Mat, since Mat memory lives in the
// WASM heap and is gone the instant .delete() runs.
function matToBuffer(cv, mat) {
  let rgba = mat;
  let temp = null;
  if (mat.channels() === 1) {
    temp = new cv.Mat();
    cv.cvtColor(mat, temp, cv.COLOR_GRAY2RGBA, 0);
    rgba = temp;
  } else if (mat.channels() === 3) {
    temp = new cv.Mat();
    cv.cvtColor(mat, temp, cv.COLOR_RGB2RGBA, 0);
    rgba = temp;
  }
  const data = new Uint8ClampedArray(rgba.data);
  const width = rgba.cols;
  const height = rgba.rows;
  if (temp) temp.delete();
  return { data, width, height };
}

function runMorphology(cv, { data, width, height }, { operation, kernelSize, iterations }) {
  const imageData = new ImageData(new Uint8ClampedArray(data), width, height);
  const src = cv.matFromImageData(imageData);
  const dst = new cv.Mat();
  const ksize = oddKernel(kernelSize);
  const kernel = cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(ksize, ksize));
  const anchor = new cv.Point(-1, -1);
  try {
    switch (operation) {
      case "dilate":
        cv.dilate(src, dst, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "erode":
        cv.erode(src, dst, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "open":
        cv.morphologyEx(src, dst, cv.MORPH_OPEN, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      case "close":
        cv.morphologyEx(src, dst, cv.MORPH_CLOSE, kernel, anchor, iterations, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
        break;
      default:
        throw new Error(`Unknown morphology operation: ${operation}`);
    }
    return { result: matToBuffer(cv, dst), shapes: null };
  } finally {
    src.delete();
    dst.delete();
    kernel.delete();
  }
}

function hasRightAngles(approx) {
  const pts = [];
  for (let i = 0; i < 4; i++) {
    pts.push({ x: approx.data32S[i * 2], y: approx.data32S[i * 2 + 1] });
  }
  for (let i = 0; i < 4; i++) {
    const prev = pts[(i + 3) % 4];
    const curr = pts[i];
    const next = pts[(i + 1) % 4];
    const v1 = { x: prev.x - curr.x, y: prev.y - curr.y };
    const v2 = { x: next.x - curr.x, y: next.y - curr.y };
    const mag1 = Math.hypot(v1.x, v1.y) || 1;
    const mag2 = Math.hypot(v2.x, v2.y) || 1;
    const cosAngle = (v1.x * v2.x + v1.y * v2.y) / (mag1 * mag2);
    if (Math.abs(cosAngle) > 0.35) return false; // ~70°-110° tolerance
  }
  return true;
}

function classifyContour(approx, area, peri, rect) {
  const vertices = approx.rows;
  const circularity = peri > 0 ? (4 * Math.PI * area) / (peri * peri) : 0;
  if (vertices === 3) return "Triangle";
  if (vertices === 4) {
    if (!hasRightAngles(approx)) return "Quadrilateral";
    const aspect = rect.width / Math.max(1, rect.height);
    return aspect > 0.9 && aspect < 1.1 ? "Square" : "Rectangle";
  }
  if (vertices === 5) return "Pentagon";
  if (vertices === 6) return "Hexagon";
  return circularity > 0.78 ? "Circle" : `Polygon (${vertices} sides)`;
}

// Contour detection cost scales with pixel count. Detection runs on a capped-size copy and
// the resulting contours/rects are scaled back up to the original image's coordinate space.
const DETECT_MAX_DIMENSION = 900;

function runDetectShapes(cv, { data, width, height }, { minAreaPct }) {
  const imageData = new ImageData(new Uint8ClampedArray(data), width, height);
  const src = cv.matFromImageData(imageData);
  const scale = Math.min(1, DETECT_MAX_DIMENSION / Math.max(width, height));
  const small = new cv.Mat();
  const gray = new cv.Mat();
  const blurred = new cv.Mat();
  const thresh = new cv.Mat();
  const noiseKernel = cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(3, 3));
  const contours = new cv.MatVector();
  const hierarchy = new cv.Mat();
  const output = src.clone();

  try {
    if (scale < 1) {
      cv.resize(src, small, new cv.Size(0, 0), scale, scale, cv.INTER_AREA);
    } else {
      src.copyTo(small);
    }

    cv.cvtColor(small, gray, cv.COLOR_RGBA2GRAY, 0);
    cv.GaussianBlur(gray, blurred, new cv.Size(5, 5), 0, 0, cv.BORDER_DEFAULT);

    cv.threshold(blurred, thresh, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU);
    const totalPx = thresh.rows * thresh.cols;
    if (cv.countNonZero(thresh) > totalPx / 2) {
      cv.bitwise_not(thresh, thresh);
    }

    const anchor = new cv.Point(-1, -1);
    cv.morphologyEx(thresh, thresh, cv.MORPH_OPEN, noiseKernel, anchor, 1, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());
    cv.morphologyEx(thresh, thresh, cv.MORPH_CLOSE, noiseKernel, anchor, 1, cv.BORDER_CONSTANT, cv.morphologyDefaultBorderValue());

    cv.findContours(thresh, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);

    const imgArea = small.rows * small.cols;
    const minArea = Math.max(40, imgArea * (minAreaPct / 100));
    const strokeColor = new cv.Scalar(79, 126, 255, 255); // forge-accent, RGBA
    const inv = scale < 1 ? 1 / scale : 1;

    const shapes = [];
    for (let i = 0; i < contours.size(); i++) {
      const cnt = contours.get(i);
      const area = cv.contourArea(cnt, false);
      if (area < minArea) {
        cnt.delete();
        continue;
      }
      const peri = cv.arcLength(cnt, true);
      const approx = new cv.Mat();
      cv.approxPolyDP(cnt, approx, 0.03 * peri, true);
      const rect = cv.boundingRect(cnt);
      const type = classifyContour(approx, area, peri, rect);

      if (scale < 1) {
        for (let p = 0; p < cnt.data32S.length; p++) cnt.data32S[p] = Math.round(cnt.data32S[p] * inv);
      }
      cv.drawContours(output, contours, i, strokeColor, 2, cv.LINE_AA, hierarchy, 0);
      shapes.push({
        type,
        x: Math.round(rect.x * inv),
        y: Math.round(rect.y * inv),
        width: Math.round(rect.width * inv),
        height: Math.round(rect.height * inv),
        area: Math.round(area * inv * inv),
      });

      approx.delete();
      cnt.delete();
    }

    return { result: matToBuffer(cv, output), shapes };
  } finally {
    src.delete();
    small.delete();
    gray.delete();
    blurred.delete();
    thresh.delete();
    noiseKernel.delete();
    contours.delete();
    hierarchy.delete();
    output.delete();
  }
}

self.onmessage = async (e) => {
  const { id, type, imageData, params } = e.data;
  try {
    // Post "loading" phase immediately - the message loop is alive (unlike with importScripts)
    // so this arrives at the client right away, resetting its timeout to the generous load budget.
    self.postMessage({ id, phase: "loading" });
    const cv = await loadCv();
    // Post "processing" phase to reset timeout to the tighter processing budget.
    self.postMessage({ id, phase: "processing" });

    const { result, shapes } = type === "morphology"
      ? runMorphology(cv, imageData, params)
      : type === "detect"
      ? runDetectShapes(cv, imageData, params)
      : (() => { throw new Error(`Unknown opencv worker task: ${type}`); })();

    self.postMessage(
      { id, ok: true, width: result.width, height: result.height, buffer: result.data.buffer, shapes },
      [result.data.buffer]
    );
  } catch (err) {
    self.postMessage({ id, ok: false, error: (err && err.message) || String(err) });
  }
};
