import { useEffect, useRef, useState, useCallback } from "react";

export default function CameraCapture({ onCapture, onClose }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const streamGenRef = useRef(0); // guards against a stream resolving after it's been superseded
  const previewUrlRef = useRef(null); // object URL backing the captured-frame preview <img>
  const [error, setError] = useState(null);
  const [ready, setReady] = useState(false);
  const [snapshot, setSnapshot] = useState(null); // { previewUrl, blob, width, height }
  const [facingMode, setFacingMode] = useState("user");

  // The preview <img> uses an object URL (cheap: just a reference to the already-encoded
  // blob) rather than a data URL (a second full base64-encoded copy of the image). Object
  // URLs must be explicitly revoked or the underlying blob is kept alive for the page's
  // lifetime - this frees the previous one before creating a new one, and on unmount/close.
  const revokePreview = useCallback(() => {
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = null;
    }
  }, []);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    // Some browsers keep decoding the video element until srcObject is explicitly cleared,
    // even after every track has been stopped - detach it too, belt and braces.
    if (videoRef.current) {
      videoRef.current.pause?.();
      videoRef.current.srcObject = null;
    }
  }, []);

  const startStream = useCallback(async (mode) => {
    setError(null);
    setReady(false);
    stopStream();
    const myGeneration = ++streamGenRef.current;
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Camera access isn't supported in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      // If a newer startStream() call (e.g. a fast unmount/remount in React StrictMode, or a
      // rapid camera-flip) has already started since this request went out, this stream is
      // orphaned - stop it immediately instead of assigning it, or its track keeps running
      // in the background forever with nothing left able to reach it to stop it.
      if (myGeneration !== streamGenRef.current) {
        stream.getTracks().forEach(t => t.stop());
        return;
      }
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setReady(true);
    } catch (err) {
      if (myGeneration !== streamGenRef.current) return; // superseded - ignore stale error
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setError("Camera permission was denied. Allow camera access in your browser settings and try again.");
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        setError("No camera was found on this device.");
      } else {
        setError(`Could not access the camera: ${err.message || err.name}`);
      }
    }
  }, [stopStream]);

  useEffect(() => {
    startStream(facingMode);
    return () => {
      streamGenRef.current++; // invalidate any in-flight getUserMedia from this mount
      stopStream();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facingMode]);

  // Also release the preview object URL if the component unmounts while a snapshot is showing
  // (e.g. the user closes the modal without retaking or using the photo).
  useEffect(() => () => revokePreview(), [revokePreview]);

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;

    // Capture the raw frame at its native resolution and hand it off through the exact same
    // File-based pipeline an uploaded file goes through (ImageSourceScreen.handleFile ->
    // App.jsx's handleImageLoaded) - no camera-specific resizing or encoding step here at all.
    // That shared pipeline already does createImageBitmap() + the same MAX_EDIT_DIMENSION cap
    // (see imageSizing.js) for every image regardless of source, so this guarantees a captured
    // photo is treated identically to an uploaded one from this point on - there is no separate
    // "camera" code path left to diverge or be slower.
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);

    canvas.toBlob((blob) => {
      if (!blob) return;
      revokePreview();
      const previewUrl = URL.createObjectURL(blob);
      previewUrlRef.current = previewUrl;
      setSnapshot({ previewUrl, blob, width: video.videoWidth, height: video.videoHeight });
    }, "image/jpeg", 0.92);
  };

  const handleRetake = () => {
    revokePreview();
    setSnapshot(null);
  };

  const handleUsePhoto = () => {
    if (!snapshot) return;
    const file = new File([snapshot.blob], `camera-capture-${Date.now()}.jpg`, { type: "image/jpeg" });
    onCapture(file);
  };

  const handleClose = () => {
    streamGenRef.current++; // invalidate any in-flight getUserMedia before manually closing
    stopStream();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-2xl bg-forge-surface border border-forge-border rounded-2xl overflow-hidden shadow-2xl animate-scale-in">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-forge-border">
          <h3 className="font-display font-600 text-forge-text text-sm">Take a Photo</h3>
          <button onClick={handleClose} className="text-forge-muted hover:text-forge-text w-8 h-8 rounded-lg hover:bg-forge-card flex items-center justify-center transition-all">
            <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4"><path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"/></svg>
          </button>
        </div>

        <div className="relative bg-black aspect-video flex items-center justify-center">
          {error ? (
            <div className="text-center px-8 py-10">
              <div className="text-3xl mb-3">🚫</div>
              <p className="text-forge-danger text-sm mb-4">{error}</p>
              <button onClick={() => startStream(facingMode)} className="px-4 py-2 rounded-lg bg-forge-accent text-white text-xs font-display font-500 hover:bg-forge-accentHover transition-all">
                Try Again
              </button>
            </div>
          ) : snapshot ? (
            <img src={snapshot.previewUrl} alt="captured" className="max-w-full max-h-full object-contain" />
          ) : (
            <>
              <video ref={videoRef} playsInline muted className="w-full h-full object-contain" />
              {!ready && (
                <div className="absolute inset-0 flex items-center justify-center text-forge-muted text-sm">
                  Starting camera…
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex items-center justify-center gap-3 px-5 py-4">
          {!error && !snapshot && (
            <>
              <button
                onClick={() => setFacingMode(f => (f === "user" ? "environment" : "user"))}
                className="px-4 py-2.5 rounded-xl border border-forge-border text-forge-muted hover:text-forge-text hover:border-forge-accent/50 text-xs font-display font-500 transition-all"
              >
                Flip Camera
              </button>
              <button
                onClick={handleCapture}
                disabled={!ready}
                className="px-6 py-2.5 rounded-xl bg-forge-accent hover:bg-forge-accentHover disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-display font-600 transition-all flex items-center gap-2"
              >
                <span className="w-3 h-3 rounded-full bg-white inline-block" />
                Capture
              </button>
            </>
          )}
          {snapshot && (
            <>
              <button onClick={handleRetake} className="px-4 py-2.5 rounded-xl border border-forge-border text-forge-muted hover:text-forge-text hover:border-forge-accent/50 text-xs font-display font-500 transition-all">
                Retake
              </button>
              <button onClick={handleUsePhoto} className="px-6 py-2.5 rounded-xl bg-forge-success hover:opacity-90 text-white text-sm font-display font-600 transition-all">
                Use This Photo
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
