import { useEffect, useRef, useState, useCallback, memo } from "react";

function ImageWorkspace({ original, imageData, activeTool, shapeSettings, onCommitShape }) {
  const [mode, setMode] = useState("split"); // "original" | "processed" | "split"
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const dragRef = useRef(null);
  const [drawing, setDrawing] = useState(false);

  const hasImageData = !!imageData;

  // Paint the current processed ImageData onto the visible canvas whenever it changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageData) return;
    const t0 = performance.now();
    canvas.width = imageData.width;
    canvas.height = imageData.height;
    const ctx = canvas.getContext("2d");
    ctx.putImageData(imageData, 0, 0);
    console.log(`PixelForge: canvas repaint (${imageData.width}×${imageData.height}) took ${(performance.now() - t0).toFixed(0)}ms`);
  }, [imageData]);

  useEffect(() => {
    const overlay = overlayRef.current;
    if (!overlay || !imageData) return;
    overlay.width = imageData.width;
    overlay.height = imageData.height;
  }, [imageData]);

  const getCanvasPoint = useCallback((e) => {
    const canvas = overlayRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }, []);

  const drawShapePreview = useCallback((ctx, start, end) => {
    const { type, color, strokeWidth, fill, fillColor } = shapeSettings;
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.strokeStyle = color;
    ctx.fillStyle = fillColor;
    ctx.lineWidth = strokeWidth;
    ctx.lineCap = "round";
    ctx.beginPath();
    if (type === "rectangle") {
      const w = end.x - start.x, h = end.y - start.y;
      ctx.rect(start.x, start.y, w, h);
    } else if (type === "circle") {
      const r = Math.hypot(end.x - start.x, end.y - start.y);
      ctx.arc(start.x, start.y, r, 0, Math.PI * 2);
    } else if (type === "line") {
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(end.x, end.y);
    }
    if (fill && type !== "line") ctx.fill();
    ctx.stroke();
  }, [shapeSettings]);

  const handlePointerDown = (e) => {
    if (activeTool !== "shapes" || mode === "original") return;
    const pt = getCanvasPoint(e);
    dragRef.current = pt;
    setDrawing(true);
  };

  const handlePointerMove = (e) => {
    if (!drawing || activeTool !== "shapes") return;
    const start = dragRef.current;
    const end = getCanvasPoint(e);
    const overlay = overlayRef.current;
    drawShapePreview(overlay.getContext("2d"), start, end);
  };

  const handlePointerUp = (e) => {
    if (!drawing || activeTool !== "shapes") return;
    setDrawing(false);
    const start = dragRef.current;
    const end = getCanvasPoint(e);
    dragRef.current = null;
    const overlay = overlayRef.current;
    overlay.getContext("2d").clearRect(0, 0, overlay.width, overlay.height);

    if (Math.hypot(end.x - start.x, end.y - start.y) < 3) return; // ignore accidental clicks

    // Merge the shape permanently into a clone of the current processed image
    const canvas = canvasRef.current;
    const mergeCanvas = document.createElement("canvas");
    mergeCanvas.width = canvas.width;
    mergeCanvas.height = canvas.height;
    const mctx = mergeCanvas.getContext("2d");
    mctx.putImageData(imageData, 0, 0);
    drawShapePreview(mctx, start, end);
    const newImageData = mctx.getImageData(0, 0, mergeCanvas.width, mergeCanvas.height);
    onCommitShape(newImageData, `Added ${shapeSettings.type}`);
  };

  return (
    <div className="flex flex-col h-full gap-3">
      {/* Mode toggle */}
      <div className="flex items-center gap-2">
        <div className="flex bg-forge-surface rounded-lg border border-forge-border p-0.5 gap-0.5">
          {[
            { id: "original", label: "Original" },
            { id: "processed", label: "Processed" },
            { id: "split", label: "Split" },
          ].map(m => (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`px-3 py-1 rounded-md text-xs font-display font-500 transition-all
                ${mode === m.id ? "bg-forge-accent text-white" : "text-forge-muted hover:text-forge-text"}`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <div className="flex-1" />
        {activeTool === "shapes" && mode !== "original" && (
          <span className="text-forge-accent text-xs font-mono animate-pulse-soft">Click & drag on the image to draw</span>
        )}
        <span className="text-forge-muted text-xs font-mono">{original?.name}</span>
      </div>

      {/* Canvas area - the canvas/overlay pair is rendered ONCE and stays mounted across mode
          switches (visibility controlled by CSS, not conditional unmounting). Previously each
          mode branch had its own <canvas>, so switching modes destroyed and recreated the DOM
          node; since the paint effect only re-runs on imageData changes (not on mode changes),
          the freshly-recreated canvas stayed blank until the next edit was applied. */}
      <div className="flex-1 rounded-xl overflow-hidden checkerboard border border-forge-border relative">
        <div className="flex h-full">
          <div
            className={`flex-1 items-center justify-center p-3 ${mode === "processed" ? "hidden" : "flex"} ${mode === "split" ? "border-r border-forge-border/50" : ""}`}
          >
            <div className="text-center">
              {mode === "split" && <p className="text-forge-muted text-xs font-mono mb-2 uppercase tracking-widest">Before</p>}
              <img
                src={original.url}
                alt="original"
                className="max-w-full max-h-full object-contain rounded-lg shadow-xl animate-fade-in"
                style={{ maxHeight: mode === "split" ? "calc(100% - 32px)" : "calc(100vh - 220px)" }}
              />
            </div>
          </div>

          <div className={`flex-1 items-center justify-center p-3 ${mode === "original" ? "hidden" : "flex"}`}>
            <div className="text-center">
              {mode === "split" && <p className="text-forge-muted text-xs font-mono mb-2 uppercase tracking-widest">After</p>}
              <div className="relative inline-block">
                <canvas
                  ref={canvasRef}
                  className="max-w-full rounded-lg shadow-xl block animate-fade-in"
                  style={{ maxHeight: mode === "split" ? "calc(100vh - 260px)" : "calc(100vh - 220px)" }}
                />
                <canvas
                  ref={overlayRef}
                  className="absolute inset-0 w-full h-full cursor-crosshair"
                  onPointerDown={handlePointerDown}
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Image metadata */}
      <div className="flex gap-3 text-xs font-mono text-forge-muted flex-wrap">
        <span>📁 {(original.size / 1024).toFixed(1)} KB</span>
        <span>🖼 {original.type.split("/")[1]?.toUpperCase() || "IMG"}</span>
        {hasImageData && <span>📐 {imageData.width}×{imageData.height}</span>}
        {original.wasScaled && original.originalDims && (
          <span className="text-forge-warning" title="Large images are scaled down for smooth, fast editing">
            ⚡ scaled from {original.originalDims.width}×{original.originalDims.height} for speed
          </span>
        )}
        <span className="flex-1" />
        {hasImageData && <span className="text-forge-success">✓ Live preview</span>}
      </div>
    </div>
  );
}

export default memo(ImageWorkspace);
