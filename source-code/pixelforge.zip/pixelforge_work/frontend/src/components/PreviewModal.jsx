import { useEffect, useRef, useState } from "react";
import { exportImageData } from "../utils/exportUtils";

export default function PreviewModal({ imageData, filenameBase, onClose }) {
  const canvasRef = useRef(null);
  const [downloading, setDownloading] = useState(null);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageData) return;
    canvas.width = imageData.width;
    canvas.height = imageData.height;
    canvas.getContext("2d").putImageData(imageData, 0, 0);
  }, [imageData]);

  const handleDownload = async (format) => {
    setDownloading(format);
    setError(null);
    try {
      await exportImageData(imageData, format, filenameBase);
      setDone(format);
      setTimeout(() => setDone(null), 2000);
    } catch (err) {
      setError(`Couldn't export ${format.toUpperCase()}: ${err.message}`);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-3xl bg-forge-surface border border-forge-border rounded-2xl overflow-hidden shadow-2xl animate-scale-in flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-forge-border shrink-0">
          <h3 className="font-display font-600 text-forge-text text-sm">Preview Result</h3>
          <button onClick={onClose} className="text-forge-muted hover:text-forge-text w-8 h-8 rounded-lg hover:bg-forge-card flex items-center justify-center transition-all">
            <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4"><path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"/></svg>
          </button>
        </div>

        <div className="flex-1 overflow-auto checkerboard flex items-center justify-center p-6">
          <canvas ref={canvasRef} className="max-w-full max-h-[55vh] rounded-lg shadow-xl" />
        </div>

        <div className="px-5 py-4 border-t border-forge-border shrink-0">
          <div className="flex items-center justify-between mb-3">
            <p className="text-forge-muted text-xs">
              {imageData ? `${imageData.width} × ${imageData.height}px` : ""}
            </p>
            {error && <p className="text-forge-danger text-xs">{error}</p>}
          </div>
          <div className="grid grid-cols-3 gap-2">
            {["jpg", "png", "bmp"].map(fmt => (
              <button
                key={fmt}
                onClick={() => handleDownload(fmt)}
                disabled={downloading !== null}
                className="py-2.5 rounded-xl bg-forge-accent hover:bg-forge-accentHover disabled:opacity-50 text-white text-sm font-display font-600 transition-all flex items-center justify-center gap-1.5"
              >
                {downloading === fmt ? (
                  <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : done === fmt ? (
                  "✓ Saved"
                ) : (
                  <>Download {fmt.toUpperCase()}</>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
