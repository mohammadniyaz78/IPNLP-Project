import { useState, useRef, useCallback } from "react";
import CameraCapture from "./CameraCapture";

const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/bmp", "image/webp", "image/gif"];

export default function ImageSourceScreen({ onImageLoaded }) {
  const [dragging, setDragging] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [fileError, setFileError] = useState(null);
  const inputRef = useRef();

  const handleFile = useCallback((file) => {
    setFileError(null);
    if (!file) return;
    const isImage = file.type.startsWith("image/") || ACCEPTED_TYPES.includes(file.type);
    if (!isImage) {
      setFileError("That file doesn't look like a supported image. Try JPG, PNG, BMP or WEBP.");
      return;
    }
    const url = URL.createObjectURL(file);
    onImageLoaded({ file, url, name: file.name, size: file.size, type: file.type || "image/png" });
  }, [onImageLoaded]);

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const handleCameraCapture = (file) => {
    setShowCamera(false);
    handleFile(file);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full gap-6 animate-fade-in">
      <div className="text-center mb-2">
        <h2 className="font-display font-700 text-forge-text text-2xl mb-2">Add an image to get started</h2>
        <p className="text-forge-muted text-sm">Upload a file from your device, or take a photo with your camera</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-5 w-full max-w-2xl">
        {/* Upload Image card */}
        <div
          className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed transition-all duration-200 cursor-pointer select-none px-6 py-10
            ${dragging ? "drop-zone-active border-forge-accent bg-forge-accent/5" : "border-forge-border bg-forge-card/40 hover:border-forge-accent/50 hover:bg-forge-card/60"}`}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          onClick={() => inputRef.current.click()}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={e => handleFile(e.target.files[0])}
          />
          <div className={`transition-all duration-200 mb-4 ${dragging ? "text-forge-accent scale-110" : "text-forge-muted"}`}>
            <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" className="w-14 h-14" strokeWidth="1.5">
              <rect x="8" y="14" width="48" height="36" rx="4" />
              <circle cx="22" cy="26" r="4" />
              <path d="M8 38l14-10 10 8 8-6 14 10" />
              <path d="M32 6v8M28 9l4-4 4 4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <p className="text-forge-text font-display font-600 text-lg mb-1.5">
            {dragging ? "Release to upload" : "Upload Image"}
          </p>
          <p className="text-forge-muted text-xs mb-4 text-center">Drag & drop, or click to browse<br />JPG, PNG, BMP, WEBP</p>
          <span className="px-4 py-2 rounded-lg bg-forge-accent/15 text-forge-accent text-xs font-display font-600">Choose File</span>
        </div>

        {/* Take Image card */}
        <div
          className="relative flex flex-col items-center justify-center rounded-2xl border-2 border-forge-border bg-forge-card/40 hover:border-forge-accent/50 hover:bg-forge-card/60 transition-all duration-200 cursor-pointer select-none px-6 py-10"
          onClick={() => setShowCamera(true)}
        >
          <div className="text-forge-muted mb-4">
            <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" className="w-14 h-14" strokeWidth="1.5">
              <path d="M8 22a4 4 0 014-4h6l3-5h14l3 5h6a4 4 0 014 4v26a4 4 0 01-4 4H12a4 4 0 01-4-4V22z" />
              <circle cx="32" cy="34" r="9" />
            </svg>
          </div>
          <p className="text-forge-text font-display font-600 text-lg mb-1.5">Take Image</p>
          <p className="text-forge-muted text-xs mb-4 text-center">Use your device camera<br />to capture a live photo</p>
          <span className="px-4 py-2 rounded-lg bg-forge-accent/15 text-forge-accent text-xs font-display font-600">Open Camera</span>
        </div>
      </div>

      {fileError && (
        <p className="text-forge-danger text-xs font-mono max-w-md text-center">{fileError}</p>
      )}

      <div className="flex gap-2">
        {["JPG", "PNG", "BMP", "WEBP", "GIF"].map(fmt => (
          <span key={fmt} className="px-2.5 py-1 rounded-md bg-forge-surface border border-forge-border text-forge-muted text-xs font-mono">
            {fmt}
          </span>
        ))}
      </div>

      {showCamera && (
        <CameraCapture onCapture={handleCameraCapture} onClose={() => setShowCamera(false)} />
      )}
    </div>
  );
}
