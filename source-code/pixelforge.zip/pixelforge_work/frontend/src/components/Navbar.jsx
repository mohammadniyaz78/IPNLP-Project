import { memo } from "react";
import ThemeToggle from "./ThemeToggle";

function Navbar({ image, onLogoClick, onStartOver, startOverDisabled }) {
  return (
    <nav className="h-14 border-b border-forge-border bg-forge-surface flex items-center px-6 gap-6 shrink-0">
      <button className="flex items-center gap-2.5" onClick={onLogoClick} title="Back to home">
        <div className="w-7 h-7 rounded-lg bg-forge-accent flex items-center justify-center">
          <svg viewBox="0 0 20 20" fill="white" className="w-4 h-4">
            <path d="M3 4a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm0 8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1v-3zm8-8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1V4zm0 8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-3z"/>
          </svg>
        </div>
        <span className="font-display font-700 text-forge-text text-base tracking-tight">PixelForge</span>
        <span className="text-[10px] font-mono bg-forge-accent/20 text-forge-accent px-1.5 py-0.5 rounded">BETA</span>
      </button>

      {image && (
        <span className="text-forge-muted text-xs font-mono truncate max-w-[220px] hidden sm:inline">{image.name}</span>
      )}

      <div className="flex-1" />

      <div className="flex items-center gap-1 text-sm text-forge-muted">
        <span className="w-2 h-2 rounded-full bg-forge-success inline-block mr-1.5" />
        Ready
      </div>

      {onStartOver && (
        <button
          onClick={() => !startOverDisabled && onStartOver()}
          disabled={startOverDisabled}
          title={startOverDisabled ? "Processing… please wait" : "Start over with a new image"}
          className="text-xs font-display font-500 text-forge-muted hover:text-forge-text px-3 py-1.5 rounded-lg hover:bg-forge-card transition-all disabled:opacity-40 disabled:cursor-wait disabled:hover:bg-transparent disabled:hover:text-forge-muted"
        >
          New Image
        </button>
      )}

      <ThemeToggle />
    </nav>
  );
}

export default memo(Navbar);
