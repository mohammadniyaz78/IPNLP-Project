import { memo } from "react";

const tools = [
  { id: "upload", icon: "⬆", label: "Upload" },
  { id: "grayscale", icon: "◑", label: "Gray" },
  { id: "brightness", icon: "☀", label: "Bright" },
  { id: "blur", icon: "◌", label: "Blur" },
  { id: "sharpen", icon: "◆", label: "Sharp" },
  { id: "edges", icon: "⬡", label: "Edges" },
  { id: "histogram", icon: "▨", label: "Hist" },
  { id: "shapes", icon: "△", label: "Shapes" },
  { id: "morphology", icon: "▦", label: "Morph" },
  { id: "detect", icon: "⬟", label: "Detect" },
];

function LeftToolbar({ activeTool, onToolSelect, disabled }) {
  return (
    <div className="w-16 bg-forge-surface border-r border-forge-border flex flex-col items-center py-3 gap-1">
      {tools.map(t => (
        <button
          key={t.id}
          onClick={() => !disabled && onToolSelect(t.id)}
          disabled={disabled}
          title={disabled ? "Processing… please wait" : t.label}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center gap-0.5 transition-all text-lg
            ${disabled ? "opacity-40 cursor-wait" : ""}
            ${activeTool === t.id
              ? "bg-forge-accent text-white shadow-lg shadow-forge-accent/30"
              : "text-forge-muted hover:bg-forge-card hover:text-forge-text"}`}
        >
          <span className="text-base leading-none">{t.icon}</span>
          <span className="text-[8px] font-mono leading-none">{t.label}</span>
        </button>
      ))}
      <div className="flex-1" />
    </div>
  );
}

export default memo(LeftToolbar);
