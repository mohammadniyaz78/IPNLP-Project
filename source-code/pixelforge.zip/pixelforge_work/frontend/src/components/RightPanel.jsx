import { useEffect, useRef, useState, useCallback, memo } from "react";
import { exportImageData } from "../utils/exportUtils";
import { runImageOp } from "../utils/workerClient";

// Throttles rapid-fire slider input events (a mouse/touch drag can fire far more 'input'
// events than the screen can even paint) down to at most one state update per animation
// frame, so dragging stays smooth instead of queuing up a React re-render per pixel of drag.
function useRafThrottledState(initial) {
  const [value, setValue] = useState(initial);
  const frameRef = useRef(null);
  const latestRef = useRef(initial);

  const setThrottled = useCallback((next) => {
    latestRef.current = next;
    if (frameRef.current) return;
    frameRef.current = requestAnimationFrame(() => {
      frameRef.current = null;
      setValue(latestRef.current);
    });
  }, []);

  useEffect(() => () => { if (frameRef.current) cancelAnimationFrame(frameRef.current); }, []);

  return [value, setThrottled];
}

const Slider = memo(function Slider({ label, value, onChange, min, max, step = 1, unit = "" }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-forge-muted text-xs">{label}</span>
        <span className="text-forge-text text-xs font-mono">{value}{unit}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-1.5 rounded-full bg-forge-border appearance-none cursor-pointer"
      />
    </div>
  );
});

function ApplyButton({ onClick, children = "Apply", isProcessing, label }) {
  return (
    <button
      onClick={onClick}
      disabled={isProcessing}
      className="w-full mt-1 py-2 rounded-lg bg-forge-accent hover:bg-forge-accentHover disabled:opacity-60 disabled:cursor-wait text-white text-xs font-display font-600 transition-all flex items-center justify-center gap-2"
    >
      {isProcessing ? (
        <>
          <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" />
          {label || "Processing…"}
        </>
      ) : (
        children
      )}
    </button>
  );
}

function HistogramChart({ imageData }) {
  const canvasRef = useRef(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  // Whether the CURRENT image (the one the histogram was just computed from) is effectively
  // grayscale - i.e. every pixel has R=G=B, which is exactly what "Applied Grayscale" produces.
  const [isGrayscale, setIsGrayscale] = useState(false);

  // Recomputes every time `imageData` changes identity - which happens on every history push,
  // i.e. every time the user uploads, captures, or applies an edit to the image. There's no
  // separate "last analyzed image" reference kept anywhere else that could go stale: this
  // effect always reads whatever ImageData is currently at the top of history.
  useEffect(() => {
    if (!imageData) return;
    let cancelled = false;
    setError(null);
    setIsLoading(true);
    runImageOp("histogram", imageData, {})
      .then((hist) => {
        if (cancelled) return;
        const { r, g, b, lum } = hist;
        const canvas = canvasRef.current;
        if (!canvas) return;
        const w = canvas.width, h = canvas.height;
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, w, h);

        const drawChannel = (arr, color, max) => {
          ctx.beginPath();
          ctx.strokeStyle = color;
          ctx.lineWidth = 1;
          for (let i = 0; i < 256; i++) {
            const x = (i / 255) * w;
            const y = h - (arr[i] / max) * h;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.stroke();
        };

        // A grayscale image (R=G=B at every pixel) would otherwise draw three identical,
        // perfectly overlapping R/G/B curves - technically correct but misleading, since it
        // reads as "one color channel" rather than what it actually is. Detect that case and
        // draw a single intensity curve instead, which is what a "grayscale histogram" means.
        let gray = true;
        for (let i = 0; i < 256 && gray; i++) {
          if (r[i] !== g[i] || g[i] !== b[i]) gray = false;
        }
        setIsGrayscale(gray);

        if (gray) {
          drawChannel(lum, "#c9ced9", Math.max(...lum, 1));
        } else {
          const max = Math.max(...r, ...g, ...b, 1);
          drawChannel(r, "#ff5a5a", max);
          drawChannel(g, "#3ecfa0", max);
          drawChannel(b, "#4f7eff", max);
        }
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || "Couldn't compute histogram");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => { cancelled = true; };
  }, [imageData]);

  return (
    <div>
      <p className="text-forge-muted text-[11px] mb-1.5">
        {isGrayscale ? "Grayscale intensity distribution" : "Live RGB distribution"} of the current image ({imageData?.width}×{imageData?.height}).
      </p>
      <div className="relative">
        <canvas ref={canvasRef} width={220} height={110} className="w-full rounded-lg bg-forge-card border border-forge-border" />
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-forge-card/70 rounded-lg text-forge-muted text-[11px]">
            <span className="w-3 h-3 border-2 border-forge-muted/40 border-t-forge-accent rounded-full animate-spin" />
            Computing…
          </div>
        )}
      </div>
      {error && <p className="text-forge-danger text-[11px] mt-1.5">{error}</p>}
      <div className="flex justify-center gap-3 mt-2 text-[10px] font-mono">
        {isGrayscale ? (
          <span className="text-[#c9ced9]">Gray</span>
        ) : (
          <>
            <span className="text-[#ff5a5a]">R</span>
            <span className="text-[#3ecfa0]">G</span>
            <span className="text-[#4f7eff]">B</span>
          </>
        )}
      </div>
    </div>
  );
}

// Segmented control shared by the Morphology and Detect panels (looks like the existing
// Shape-type picker in the Shapes tool, for visual consistency).
function SegmentedControl({ options, value, onChange }) {
  return (
    <div className="flex gap-1.5">
      {options.map(opt => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`flex-1 py-1.5 rounded-lg border text-xs font-display font-500 capitalize transition-all
            ${value === opt.value ? "bg-forge-accent text-white border-forge-accent" : "border-forge-border text-forge-muted hover:text-forge-text"}`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export default function RightPanel(props) {
  const {
    activeTool, image, imageData, history, historyIndex, onUndo, onRedo, onReset,
    shapeSettings, setShapeSettings,
    onApplyGrayscale, onApplyBrightness, onApplyBlur, onApplySharpen, onApplyEdges,
    onApplyMorphology, onApplyDetectShapes, detectedShapes,
    onOpenPreview, applyError, isProcessing, processingLabel,
  } = props;

  // Slider values live locally in this component (not lifted to App) so dragging a slider
  // only re-renders RightPanel, not the whole app tree (Navbar/LeftToolbar/ImageWorkspace).
  // rAF-throttled so a fast drag can't queue more than one re-render per animation frame.
  const [brightness, setBrightness] = useRafThrottledState(0);
  const [contrast, setContrast] = useRafThrottledState(0);
  const [blurRadius, setBlurRadius] = useRafThrottledState(4);
  const [sharpenAmount, setSharpenAmount] = useRafThrottledState(1.5);
  const [edgeThreshold, setEdgeThreshold] = useRafThrottledState(40);
  const [morphOp, setMorphOp] = useState("dilate");
  const [kernelSize, setKernelSize] = useRafThrottledState(3);
  const [iterations, setIterations] = useRafThrottledState(1);
  const [minShapeSize, setMinShapeSize] = useRafThrottledState(0.5);

  const [quickDownloading, setQuickDownloading] = useState(null);
  const [quickError, setQuickError] = useState(null);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  const handleQuickDownload = async (format) => {
    if (!imageData) return;
    setQuickDownloading(format);
    setQuickError(null);
    try {
      const base = (image?.name || "pixelforge-export").replace(/\.[^/.]+$/, "");
      await exportImageData(imageData, format, base);
    } catch (err) {
      setQuickError(`${format.toUpperCase()} export failed`);
    } finally {
      setQuickDownloading(null);
    }
  };

  return (
    <div className="w-72 bg-forge-surface border-l border-forge-border flex flex-col">
      {/* Tool Settings Header */}
      <div className="px-4 py-3 border-b border-forge-border">
        <h3 className="text-forge-text font-display font-600 text-sm">Settings</h3>
        <p className="text-forge-muted text-xs mt-0.5 capitalize">
          {activeTool ? `Tool: ${activeTool}` : "No tool selected"}
        </p>
      </div>

      {/* Settings area */}
      <div className="flex-1 px-4 py-3 space-y-3 overflow-y-auto">
        {applyError && (
          <div className="text-forge-danger text-xs bg-forge-danger/10 border border-forge-danger/30 rounded-lg px-3 py-2">
            {applyError}
          </div>
        )}
        {(!activeTool || activeTool === "upload") && (
          <div className="text-forge-muted text-xs text-center py-8 opacity-60">
            <div className="text-2xl mb-2">⚙️</div>
            Select a tool from the left panel to see settings
          </div>
        )}

        {activeTool === "grayscale" && (
          <div className="space-y-2">
            <p className="text-forge-muted text-xs leading-relaxed">Converts the image to luminance-weighted grayscale.</p>
            <ApplyButton onClick={onApplyGrayscale} isProcessing={isProcessing}>Apply Grayscale</ApplyButton>
          </div>
        )}

        {activeTool === "brightness" && (
          <div className="space-y-4">
            <Slider label="Brightness" value={brightness} onChange={setBrightness} min={-100} max={100} />
            <Slider label="Contrast" value={contrast} onChange={setContrast} min={-100} max={100} />
            <ApplyButton onClick={() => onApplyBrightness(brightness, contrast)} isProcessing={isProcessing}>Apply Brightness/Contrast</ApplyButton>
          </div>
        )}

        {activeTool === "blur" && (
          <div className="space-y-4">
            <Slider label="Blur Radius" value={blurRadius} onChange={setBlurRadius} min={1} max={20} unit="px" />
            <ApplyButton onClick={() => onApplyBlur(blurRadius)} isProcessing={isProcessing}>Apply Blur</ApplyButton>
          </div>
        )}

        {activeTool === "sharpen" && (
          <div className="space-y-4">
            <Slider label="Sharpen Amount" value={sharpenAmount} onChange={setSharpenAmount} min={0} max={5} step={0.1} />
            <ApplyButton onClick={() => onApplySharpen(sharpenAmount)} isProcessing={isProcessing}>Apply Sharpen</ApplyButton>
          </div>
        )}

        {activeTool === "edges" && (
          <div className="space-y-4">
            <Slider label="Edge Threshold" value={edgeThreshold} onChange={setEdgeThreshold} min={0} max={255} />
            <p className="text-forge-muted text-xs leading-relaxed">Sobel operator edge detection. Higher threshold keeps only the strongest edges.</p>
            <ApplyButton onClick={() => onApplyEdges(edgeThreshold)} isProcessing={isProcessing}>Apply Edge Detection</ApplyButton>
          </div>
        )}

        {activeTool === "histogram" && (
          <div className="space-y-2">
            <div className="flex items-center justify-end">
              <span className="shrink-0 text-[10px] font-mono px-2 py-0.5 rounded-full bg-forge-success/15 text-forge-success">Auto-updates</span>
            </div>
            <HistogramChart imageData={imageData} />
            <p className="text-forge-muted text-[11px] leading-relaxed">
              This is a read-only analysis view — it updates automatically whenever the image changes (upload, camera capture, or any applied edit). There's nothing to apply here.
            </p>
          </div>
        )}

        {activeTool === "shapes" && (
          <div className="space-y-4">
            <div>
              <span className="text-forge-muted text-xs block mb-1.5">Shape</span>
              <div className="flex gap-1.5">
                {["rectangle", "circle", "line"].map(t => (
                  <button
                    key={t}
                    onClick={() => setShapeSettings(s => ({ ...s, type: t }))}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-display font-500 capitalize transition-all
                      ${shapeSettings.type === t ? "bg-forge-accent text-white border-forge-accent" : "border-forge-border text-forge-muted hover:text-forge-text"}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1">
                <span className="text-forge-muted text-xs block mb-1.5">Stroke Color</span>
                <input
                  type="color"
                  value={shapeSettings.color}
                  onChange={e => setShapeSettings(s => ({ ...s, color: e.target.value }))}
                  className="w-full h-8 rounded-lg border border-forge-border bg-transparent cursor-pointer"
                />
              </div>
              <div className="flex-1">
                <span className="text-forge-muted text-xs block mb-1.5">Fill Color</span>
                <input
                  type="color"
                  value={shapeSettings.fillColor}
                  onChange={e => setShapeSettings(s => ({ ...s, fillColor: e.target.value }))}
                  disabled={shapeSettings.type === "line"}
                  className="w-full h-8 rounded-lg border border-forge-border bg-transparent cursor-pointer disabled:opacity-30"
                />
              </div>
            </div>

            {shapeSettings.type !== "line" && (
              <label className="flex items-center gap-2 text-xs text-forge-muted cursor-pointer">
                <input
                  type="checkbox"
                  checked={shapeSettings.fill}
                  onChange={e => setShapeSettings(s => ({ ...s, fill: e.target.checked }))}
                />
                Fill shape
              </label>
            )}

            <Slider label="Stroke Width" value={shapeSettings.strokeWidth} onChange={v => setShapeSettings(s => ({ ...s, strokeWidth: v }))} min={1} max={20} unit="px" />

            <p className="text-forge-accent text-xs bg-forge-accent/10 rounded-lg px-3 py-2">
              Click and drag directly on the image in the workspace to draw.
            </p>
          </div>
        )}

        {activeTool === "morphology" && (
          <div className="space-y-4">
            <div>
              <span className="text-forge-muted text-xs block mb-1.5">Operation</span>
              <SegmentedControl
                options={[
                  { value: "dilate", label: "Dilate" },
                  { value: "erode", label: "Erode" },
                ]}
                value={morphOp}
                onChange={setMorphOp}
              />
              <div className="mt-1.5">
                <SegmentedControl
                  options={[
                    { value: "open", label: "Open" },
                    { value: "close", label: "Close" },
                  ]}
                  value={morphOp}
                  onChange={setMorphOp}
                />
              </div>
            </div>

            <p className="text-forge-muted text-xs leading-relaxed">
              {morphOp === "dilate" && "Grows bright regions and shrinks dark gaps — thickens edges, fills small holes."}
              {morphOp === "erode" && "Shrinks bright regions and grows dark gaps — thins edges, removes small specks."}
              {morphOp === "open" && "Erosion followed by dilation — removes small noise specks while preserving overall shape size."}
              {morphOp === "close" && "Dilation followed by erosion — fills small holes and gaps while preserving overall shape size."}
            </p>

            <Slider label="Kernel Size" value={kernelSize} onChange={setKernelSize} min={1} max={15} step={2} unit="px" />
            <Slider label="Iterations" value={iterations} onChange={setIterations} min={1} max={5} />

            <ApplyButton
              onClick={() => onApplyMorphology(morphOp, kernelSize, iterations)}
              isProcessing={isProcessing}
              label={processingLabel}
            >
              Apply {morphOp === "open" ? "Opening" : morphOp === "close" ? "Closing" : morphOp === "dilate" ? "Dilation" : "Erosion"}
            </ApplyButton>

            <p className="text-forge-muted text-[10px] leading-relaxed opacity-70">Powered by OpenCV (cv.dilate / cv.erode / cv.morphologyEx). OpenCV loads once per visit in the background - the first Apply may need a few seconds if that hasn't finished yet.</p>
          </div>
        )}

        {activeTool === "detect" && (
          <div className="space-y-4">
            <p className="text-forge-muted text-xs leading-relaxed">
              Detects triangles, squares, rectangles, circles and other polygons using OpenCV contours, and outlines each one on the image.
            </p>

            <Slider label="Sensitivity (Min Size)" value={minShapeSize} onChange={setMinShapeSize} min={0.05} max={5} step={0.05} unit="%" />
            <p className="text-forge-muted text-[11px] leading-relaxed opacity-80">
              Contours smaller than this percentage of the image area are treated as noise and ignored. Lower this if small shapes are being missed; raise it if noise/texture is being detected as shapes.
            </p>

            <ApplyButton onClick={() => onApplyDetectShapes(minShapeSize)} isProcessing={isProcessing} label={processingLabel}>
              Detect Shapes
            </ApplyButton>

            {detectedShapes && detectedShapes.length > 0 && (
              <div className="pt-1">
                <p className="text-forge-text text-xs font-display font-600 mb-1.5">Found {detectedShapes.length} shape{detectedShapes.length === 1 ? "" : "s"}</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(
                    detectedShapes.reduce((acc, s) => {
                      acc[s.type] = (acc[s.type] || 0) + 1;
                      return acc;
                    }, {})
                  ).map(([type, count]) => (
                    <span key={type} className="text-[11px] font-mono px-2 py-1 rounded-full bg-forge-accent/15 text-forge-accent">
                      {type} ×{count}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {detectedShapes && detectedShapes.length === 0 && (
              <p className="text-forge-muted text-[11px] opacity-60">No detection run yet, or no shapes found — try lowering sensitivity.</p>
            )}

            <p className="text-forge-muted text-[10px] leading-relaxed opacity-70">Powered by OpenCV (cv.findContours + cv.approxPolyDP). First use on this page loads OpenCV (~8MB) — this can take several seconds.</p>
          </div>
        )}
      </div>

      {/* Processing History */}
      <div className="border-t border-forge-border px-4 py-3">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-forge-text text-xs font-display font-600">History</h4>
          <div className="flex gap-1">
            <button onClick={onUndo} disabled={!canUndo || isProcessing} className="text-forge-muted hover:text-forge-text text-xs px-2 py-1 rounded hover:bg-forge-card transition-all disabled:opacity-30 disabled:cursor-not-allowed">Undo</button>
            <button onClick={onRedo} disabled={!canRedo || isProcessing} className="text-forge-muted hover:text-forge-text text-xs px-2 py-1 rounded hover:bg-forge-card transition-all disabled:opacity-30 disabled:cursor-not-allowed">Redo</button>
            <button onClick={onReset} disabled={!canUndo || isProcessing} className="text-forge-muted hover:text-forge-danger text-xs px-2 py-1 rounded hover:bg-forge-danger/10 transition-all disabled:opacity-30 disabled:cursor-not-allowed">Reset</button>
          </div>
        </div>
        <div className="space-y-1 max-h-28 overflow-y-auto">
          {history.length === 0 ? (
            <p className="text-forge-muted text-xs opacity-40">No operations yet</p>
          ) : (
            history.map((h, i) => (
              <div key={i} className={`flex items-center gap-2 text-xs py-1 border-b border-forge-border/40 ${i === historyIndex ? "opacity-100" : "opacity-50"}`}>
                <span className={`w-4 h-4 rounded flex items-center justify-center font-mono text-[9px] ${i === historyIndex ? "bg-forge-accent text-white" : "bg-forge-accent/20 text-forge-accent"}`}>{i + 1}</span>
                <span className="text-forge-text truncate">{h.label}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Export */}
      <div className="border-t border-forge-border px-4 py-3 space-y-2">
        <h4 className="text-forge-text text-xs font-display font-600 mb-2">Export</h4>
        {image?.wasScaled && image?.originalDims && (
          <p className="text-forge-warning text-[11px] leading-relaxed bg-forge-warning/10 rounded-lg px-2.5 py-1.5">
            Exports at {imageData?.width}×{imageData?.height} (scaled down from {image.originalDims.width}×{image.originalDims.height} for fast editing).
          </p>
        )}
        {quickError && <p className="text-forge-danger text-[11px]">{quickError}</p>}
        <div className="flex gap-1">
          {["jpg", "png", "bmp"].map(fmt => (
            <button
              key={fmt}
              onClick={() => handleQuickDownload(fmt)}
              disabled={!imageData || quickDownloading !== null}
              className="flex-1 py-1.5 rounded-lg border border-forge-border text-forge-muted text-xs font-mono hover:border-forge-accent hover:text-forge-accent transition-all disabled:opacity-30"
            >
              {quickDownloading === fmt ? "…" : fmt.toUpperCase()}
            </button>
          ))}
        </div>
        <button
          onClick={onOpenPreview}
          disabled={!imageData}
          className="w-full py-2 rounded-xl bg-forge-accent hover:bg-forge-accentHover text-white text-sm font-display font-500 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
        >
          Preview & Download
        </button>
      </div>
    </div>
  );
}
