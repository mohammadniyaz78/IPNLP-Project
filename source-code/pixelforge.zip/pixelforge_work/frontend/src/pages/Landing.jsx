import ThemeToggle from "../components/ThemeToggle";

const features = [
  { icon: "◑", title: "Pixel-level tools", desc: "Grayscale, brightness, blur, sharpen, edge detection & more" },
  { icon: "📷", title: "Upload or capture", desc: "Bring in a file or shoot straight from your camera" },
  { icon: "⬇", title: "Export anywhere", desc: "Download crisp JPG, PNG or BMP output in one click" },
];

export default function Landing({ onStart }) {
  return (
    <div className="relative h-screen w-full overflow-y-auto overflow-x-hidden bg-forge-bg">
      {/* Background */}
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-40" />
      <div className="pointer-events-none absolute -top-32 -left-24 w-96 h-96 rounded-full bg-forge-accent/25 blur-3xl animate-float" />
      <div className="pointer-events-none absolute top-1/3 -right-24 w-[28rem] h-[28rem] rounded-full bg-purple-500/20 blur-3xl animate-float-delay" />
      <div className="pointer-events-none absolute bottom-0 left-1/3 w-80 h-80 rounded-full bg-forge-success/10 blur-3xl animate-float" />

      {/* Nav */}
      <nav className="relative z-10 h-16 flex items-center px-6 sm:px-10 justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-forge-accent flex items-center justify-center shadow-lg shadow-forge-accent/30">
            <svg viewBox="0 0 20 20" fill="white" className="w-4 h-4">
              <path d="M3 4a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm0 8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1v-3zm8-8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1V4zm0 8a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-3z"/>
            </svg>
          </div>
          <span className="font-display font-700 text-forge-text text-lg tracking-tight">PixelForge</span>
          <span className="text-[10px] font-mono bg-forge-accent/20 text-forge-accent px-1.5 py-0.5 rounded">BETA</span>
        </div>
        <ThemeToggle />
      </nav>

      {/* Hero */}
      <main className="relative z-10 flex flex-col items-center text-center px-6 pt-16 pb-20 sm:pt-24">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-forge-border bg-forge-surface/80 backdrop-blur text-xs font-mono text-forge-muted mb-8 animate-slide-up">
          <span className="w-1.5 h-1.5 rounded-full bg-forge-success animate-pulse-soft" />
          Fast, in-browser image processing
        </div>

        <h1 className="font-display font-700 text-5xl sm:text-6xl md:text-7xl tracking-tight mb-5 animate-slide-up" style={{ animationDelay: "60ms" }}>
          <span className="text-forge-text">Reforge your images</span>
          <br />
          <span className="gradient-text">pixel by pixel.</span>
        </h1>

        <p className="max-w-xl text-forge-muted text-base sm:text-lg mb-10 animate-slide-up" style={{ animationDelay: "120ms" }}>
          Upload a photo or snap one live, apply professional-grade filters and effects,
          preview the result instantly, and export it in the format you need.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-4 animate-slide-up" style={{ animationDelay: "180ms" }}>
          <button
            onClick={onStart}
            className="group relative px-8 py-3.5 rounded-xl bg-forge-accent hover:bg-forge-accentHover text-white font-display font-600 text-base shadow-lg shadow-forge-accent/30 transition-all hover:scale-[1.03] active:scale-[0.98]"
          >
            <span className="flex items-center gap-2">
              Start Editing
              <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 transition-transform group-hover:translate-x-0.5">
                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </span>
          </button>
          <span className="text-forge-muted text-xs font-mono">No sign-up • Runs entirely in your browser</span>
        </div>

        {/* Feature cards */}
        <div className="grid sm:grid-cols-3 gap-4 mt-20 max-w-4xl w-full">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="rounded-2xl border border-forge-border bg-forge-surface/70 backdrop-blur p-6 text-left hover:border-forge-accent/50 transition-all animate-slide-up"
              style={{ animationDelay: `${240 + i * 80}ms` }}
            >
              <div className="w-10 h-10 rounded-xl bg-forge-accent/15 text-forge-accent flex items-center justify-center text-lg mb-4">
                {f.icon}
              </div>
              <h3 className="font-display font-600 text-forge-text text-sm mb-1.5">{f.title}</h3>
              <p className="text-forge-muted text-xs leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
