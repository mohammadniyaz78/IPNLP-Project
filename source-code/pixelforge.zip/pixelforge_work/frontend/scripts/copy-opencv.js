// Copies opencv.js out of node_modules and into public/opencv/, so the app serves it from
// the same origin instead of fetching it from docs.opencv.org at runtime.
//
// Why this exists: the Detect/Morph worker used to importScripts() opencv.js straight from
// docs.opencv.org. That's an ~10MB file, and depending on the user's network (corporate
// proxy, firewall, slow/blocked route to that host, etc.) the download could stall
// indefinitely - which surfaced as the generic "OpenCV took too long and was cancelled"
// error even on a tiny image, because the actual image processing never got a chance to
// start. Serving the same file from our own origin removes that external dependency
// entirely and lets the browser cache it like any other static asset.
//
// Runs automatically via the "postinstall" npm script, so `npm install` keeps this file in
// sync with whatever version of @techstark/opencv-js is in package.json.
import { copyFileSync, mkdirSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const src = path.join(__dirname, "..", "node_modules", "@techstark", "opencv-js", "dist", "opencv.js");
const destDir = path.join(__dirname, "..", "public", "opencv");
const dest = path.join(destDir, "opencv.js");

if (!existsSync(src)) {
  console.warn("[copy-opencv] node_modules/@techstark/opencv-js not found - skipping copy. Run `npm install` first.");
  process.exit(0);
}

mkdirSync(destDir, { recursive: true });
copyFileSync(src, dest);
console.log(`[copy-opencv] copied opencv.js -> public/opencv/opencv.js`);
