# PixelForge

## Stage 3: OpenCV Morphology, Shape Detection & Camera/Histogram fixes ✅

Complete end-to-end flow: **Landing Page → Start Editing → Upload/Take Image → Preview → Edit → Preview Result → Download**.

### What's new in this update
- **Dilation, Erosion, Opening & Closing** — new **Morph** tool, backed by real OpenCV (`cv.dilate`, `cv.erode`, `cv.morphologyEx`) via OpenCV.js (WASM), with adjustable kernel size and iterations. Opening/Closing are the dedicated noise-removal presets (erode→dilate / dilate→erode).
- **Shape Detection** — new **Detect** tool, using OpenCV contours (`cv.findContours` + `cv.approxPolyDP`) to classify Triangles, Squares, Rectangles, Pentagons, Hexagons, Circles and general Polygons, with an adjustable sensitivity threshold and an automatic noise-filtering pass (Otsu threshold + morphological open/close) before contours are extracted. Detected shapes are outlined and labeled directly on the image, and summarized in the panel.
- **Histogram fix** — the histogram now always reflects whatever image is currently on top of the undo history (upload, camera capture, or any applied edit), and correctly distinguishes a true grayscale image (a single intensity curve) from a color image (overlaid R/G/B curves) instead of drawing three identical overlapping channels for grayscale images.
- **Camera performance fix** — captured frames are now resized to the same resolution cap used for uploads (`MAX_EDIT_DIMENSION`, shared via `utils/imageSizing.js`) at the moment of capture, and encoded exactly once (previously the preview and the outgoing file were each a separate full-resolution PNG encode). Captured photos flow through the exact same load pipeline as uploaded files.
- **Animated landing page** with PixelForge branding, tagline, and a "Start Editing" CTA.
- **Light/Dark theme toggle**, persisted to `localStorage` and restored on refresh (falls back to OS preference if nothing is stored).
- **Exactly two image sources**: "Upload Image" (file picker + drag-and-drop) and "Take Image" (live camera capture via `getUserMedia`, with flip-camera, retake, and permission-error handling).
- All editing tools are **functionally real**, computed either off the main thread (JS worker) or via OpenCV/WASM on the actual pixel data:
  - Grayscale, Brightness/Contrast, Blur (box blur), Sharpen (convolution), Edge Detection (Sobel), live Histogram, Shapes (draw rectangle/circle/line by click-drag), Morph (dilate/erode/open/close), and Detect (OpenCV contour shape detection).
- Full **Undo / Redo / Reset** history stack.
- **Preview Result** modal shown before export, plus quick per-format download buttons.
- **JPG / PNG / BMP export** that always reflects the current edited pixels — BMP is hand-encoded (uncompressed 24-bit BITMAPINFOHEADER) since browsers don't natively export that format, so it can never be empty or stale.

### Structure
```
pixelforge/
├── frontend/                # React + Vite + Tailwind
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx           # branding, theme toggle, "New Image"
│   │   │   ├── ThemeToggle.jsx
│   │   │   ├── LeftToolbar.jsx        # tool list, incl. Morph & Detect
│   │   │   ├── ImageSourceScreen.jsx  # Upload Image / Take Image
│   │   │   ├── CameraCapture.jsx      # getUserMedia capture modal (fast, single-pass capture)
│   │   │   ├── ImageWorkspace.jsx     # canvas preview + shape drawing
│   │   │   ├── RightPanel.jsx         # tool settings, history, export
│   │   │   └── PreviewModal.jsx       # Preview Result → Download
│   │   ├── pages/
│   │   │   └── Landing.jsx
│   │   ├── context/
│   │   │   └── ThemeContext.jsx
│   │   ├── utils/
│   │   │   ├── imageProcessing.js   # grayscale/brightness/blur/sharpen/edges/histogram (JS worker)
│   │   │   ├── opencvLoader.js      # lazy-loads OpenCV.js (WASM) from CDN, cached
│   │   │   ├── opencvProcessing.js  # dilate/erode/open/close + contour shape detection
│   │   │   ├── imageSizing.js       # shared resolution cap (uploads + camera capture)
│   │   │   └── exportUtils.js       # PNG/JPG via canvas, hand-rolled BMP encoder
│   │   ├── App.jsx                  # routing + state management
│   │   ├── main.jsx
│   │   └── index.css                # light/dark CSS variables
│   ├── tailwind.config.js
│   └── index.html
└── backend/
    └── app.py         # Flask skeleton (unused by this flow — all processing is client-side)
```

### OpenCV.js note
The Morph and Detect tools load OpenCV.js from `docs.opencv.org` on demand (a background "warm-up" fetch starts as soon as the editor opens, so it's usually ready before you pick either tool). This requires internet access in the browser running the app; everything else in PixelForge works fully offline.

### Run frontend
```bash
cd frontend && npm install
npm run dev
```
Note: camera capture requires `https://` or `localhost` per browser security rules — `npm run dev`'s local server satisfies this.

### Run backend (optional, not required for the current flow)
```bash
cd backend && python app.py
```
