from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/health")
def health():
    return jsonify({"status": "ok", "version": "0.1.0"})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
